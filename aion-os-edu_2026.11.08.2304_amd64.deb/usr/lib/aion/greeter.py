#!/usr/bin/env python3
"""Aion OS EDU — login and lock screen (a LightDM greeter, Windows 10 style).

1. Lock view: the picture with a big clock and the date (bottom left).
2. Any key or click: the account with its 4-digit PIN box. The PIN is sent
   as soon as the 4th digit is typed (like Windows). Accounts whose password
   is not a 4-digit PIN just press Entrée.

If this greeter can't start, aion-greeter-wrapper falls back to the standard
LightDM GTK greeter, so the PC is never locked out.
"""
import json
import os
import re
import sys

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("LightDM", "1")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, LightDM  # noqa: E402

PICTURE = "/usr/share/backgrounds/aion/aion-lock.jpg"
PIN_USERS = "/etc/aion/pin-users"
STATE = "/var/lib/lightdm/aion-greeter.json"

CSS = b"""
* { font-family: Inter, sans-serif; color: #ffffff; }
.clock { font-size: 96px; font-weight: 300; }
.date { font-size: 30px; font-weight: 300; }
.name { font-size: 28px; font-weight: 400; }
.hint { font-size: 13px; }
.avatar { background: rgba(255,255,255,0.22); border-radius: 999px; min-width: 150px; min-height: 150px; font-size: 64px; }
entry { background: rgba(255,255,255,0.92); color: #000; border: 2px solid rgba(255,255,255,0.0); border-radius: 0;
        min-height: 34px; min-width: 260px; font-size: 18px; caret-color: #000; }
entry:focus { border-color: #0078d7; }
.userbtn { background: transparent; border: none; border-radius: 0; padding: 8px 14px; }
.userbtn:hover, .userbtn.current { background: rgba(255,255,255,0.18); }
.iconbtn { background: transparent; border: none; border-radius: 0; padding: 10px; }
.iconbtn:hover { background: rgba(255,255,255,0.18); }
menu, menuitem, menu label { color: #000; }
"""


def load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_state(state):
    try:
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except OSError:
        pass


def pin_users():
    try:
        with open(PIN_USERS, encoding="utf-8") as f:
            return {l.strip() for l in f if l.strip()}
    except OSError:
        return set()


class Greeter(Gtk.Window):
    def __init__(self):
        super().__init__(title="Aion")
        self.greeter = LightDM.Greeter()
        self.greeter.connect("show-prompt", self.on_prompt)
        self.greeter.connect("show-message", self.on_message)
        self.greeter.connect("authentication-complete", self.on_complete)
        self.greeter.connect_to_daemon_sync()
        self.users = LightDM.UserList.get_instance()
        self.state = load_state()
        self.pins = pin_users()
        self.user = None
        self.pending = None
        self.prompted = False
        self.fails = 0
        self.auto_submit = True

        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        screen = Gdk.Screen.get_default()
        mon = screen.get_display().get_primary_monitor() or screen.get_display().get_monitor(0)
        geo = mon.get_geometry()
        self.w, self.h = geo.width, geo.height
        self.move(geo.x, geo.y)
        self.set_default_size(self.w, self.h)
        self.set_decorated(False)

        self.overlay = Gtk.Overlay()
        self.add(self.overlay)
        self.bg = Gtk.Image()
        self.overlay.add(self.bg)
        self.set_background(blur=False)

        # lock view: clock + date, bottom left
        self.lockview = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.START, valign=Gtk.Align.END)
        self.lockview.set_margin_start(60)
        self.lockview.set_margin_bottom(90)
        self.clock = Gtk.Label(xalign=0)
        self.clock.get_style_context().add_class("clock")
        self.date = Gtk.Label(xalign=0)
        self.date.get_style_context().add_class("date")
        self.lockview.pack_start(self.clock, False, False, 0)
        self.lockview.pack_start(self.date, False, False, 0)
        self.overlay.add_overlay(self.lockview)

        # login view: avatar, name, PIN
        self.loginview = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.avatar = Gtk.Label()
        self.avatar.get_style_context().add_class("avatar")
        self.avatar.set_halign(Gtk.Align.CENTER)
        self.name = Gtk.Label()
        self.name.get_style_context().add_class("name")
        self.entry = Gtk.Entry(visibility=False, input_purpose=Gtk.InputPurpose.PIN, placeholder_text="Code PIN")
        self.entry.set_halign(Gtk.Align.CENTER)
        self.entry.connect("changed", self.on_entry_changed)
        self.entry.connect("activate", lambda e: self.submit())
        self.hint = Gtk.Label()
        self.hint.get_style_context().add_class("hint")
        for wdg in (self.avatar, self.name, self.entry, self.hint):
            self.loginview.pack_start(wdg, False, False, 0)
        self.overlay.add_overlay(self.loginview)

        # bottom left: other accounts; bottom right: accessibility + power
        self.userbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.START, valign=Gtk.Align.END)
        self.userbox.set_margin_start(20)
        self.userbox.set_margin_bottom(20)
        self.overlay.add_overlay(self.userbox)
        corner = Gtk.Box(spacing=4, halign=Gtk.Align.END, valign=Gtk.Align.END)
        corner.set_margin_end(20)
        corner.set_margin_bottom(20)
        kb = Gtk.Button()
        kb.add(Gtk.Image.new_from_icon_name("input-keyboard-symbolic", Gtk.IconSize.LARGE_TOOLBAR))
        kb.get_style_context().add_class("iconbtn")
        kb.set_tooltip_text("Clavier visuel")
        kb.connect("clicked", self.toggle_onboard)
        pw = Gtk.Button()
        pw.add(Gtk.Image.new_from_icon_name("system-shutdown-symbolic", Gtk.IconSize.LARGE_TOOLBAR))
        pw.get_style_context().add_class("iconbtn")
        pw.set_tooltip_text("Marche/Arrêt")
        pw.connect("clicked", self.power_menu)
        corner.pack_start(kb, False, False, 0)
        corner.pack_start(pw, False, False, 0)
        self.corner = corner
        self.overlay.add_overlay(corner)

        self.connect("key-press-event", self.on_key)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", lambda *_: self.show_login() if self.lockview.get_visible() else False)
        self.onboard = None
        self.tick()
        GLib.timeout_add_seconds(1, self.tick)
        self.show_all()
        self.build_userlist()
        self.show_lock()
        self.get_window().set_cursor(Gdk.Cursor.new_from_name(self.get_display(), "default"))

    def set_background(self, blur):
        try:
            pix = GdkPixbuf.Pixbuf.new_from_file(PICTURE)
            sw, sh = pix.get_width(), pix.get_height()
            scale = max(self.w / sw, self.h / sh)
            pix = pix.scale_simple(int(sw * scale) + 1, int(sh * scale) + 1, GdkPixbuf.InterpType.BILINEAR)
            x, y = (pix.get_width() - self.w) // 2, (pix.get_height() - self.h) // 2
            pix = pix.new_subpixbuf(max(0, x), max(0, y), self.w, self.h)
            if blur:  # cheap "acrylic" blur: shrink then enlarge
                small = pix.scale_simple(max(1, self.w // 24), max(1, self.h // 24), GdkPixbuf.InterpType.BILINEAR)
                pix = small.scale_simple(self.w, self.h, GdkPixbuf.InterpType.BILINEAR)
            self.bg.set_from_pixbuf(pix)
        except GLib.Error:
            prov = Gtk.CssProvider()
            prov.load_from_data(b"window { background: #0a3d7a; }")
            self.get_style_context().add_provider(prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def tick(self):
        now = GLib.DateTime.new_now_local()
        self.clock.set_text(now.format("%H:%M"))
        self.date.set_text(now.format("%A %e %B").replace("  ", " ").strip().capitalize())
        return True

    # ------------------------------------------------------------ accounts --
    def build_userlist(self):
        for c in self.userbox.get_children():
            self.userbox.remove(c)
        users = self.users.get_users()
        hinted = self.greeter.get_select_user_hint() or self.state.get("last")
        names = [u.get_name() for u in users]
        self.select_user(hinted if hinted in names else (names[0] if names else None))
        if len(users) > 1:
            for u in users:
                b = Gtk.Button()
                b.get_style_context().add_class("userbtn")
                if u.get_name() == self.user:
                    b.get_style_context().add_class("current")
                h = Gtk.Box(spacing=10)
                h.pack_start(Gtk.Image.new_from_icon_name("avatar-default-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
                h.pack_start(Gtk.Label(label=u.get_display_name() or u.get_name()), False, False, 0)
                b.add(h)
                b.connect("clicked", lambda _b, n=u.get_name(): (self.select_user(n), self.build_userlist(), self.show_login()))
                self.userbox.pack_start(b, False, False, 0)
        self.userbox.show_all()

    def select_user(self, name):
        self.user = name
        u = self.users.get_user_by_name(name) if name else None
        disp = (u.get_display_name() if u else None) or name or "Aion"
        self.name.set_text(disp)
        self.avatar.set_text(disp[:1].upper())
        no_auto = set(self.state.get("no_auto", []))
        self.auto_submit = bool(name) and name in self.pins and name not in no_auto
        self.entry.set_placeholder_text("Code PIN" if self.auto_submit else "Code PIN ou mot de passe")
        self.entry.set_max_length(4 if self.auto_submit else 0)
        self.hint.set_text("")
        self.fails = 0
        if name:
            if self.greeter.get_in_authentication():
                self.greeter.cancel_authentication()
            self.prompted = False
            self.pending = None
            self.greeter.authenticate(name)

    # ---------------------------------------------------------------- views --
    def show_lock(self):
        self.loginview.hide()
        self.userbox.hide()
        self.corner.hide()
        self.lockview.show()
        self.set_background(blur=False)

    def show_login(self):
        if self.loginview.get_visible():
            return False
        self.lockview.hide()
        self.set_background(blur=True)
        self.loginview.show()
        self.userbox.show()
        self.corner.show()
        self.entry.grab_focus()
        return True

    def on_key(self, _w, ev):
        if self.lockview.get_visible():
            self.show_login()
            if ev.string and ev.string.isdigit():
                self.entry.set_text(ev.string)
                self.entry.set_position(-1)
            return True
        if ev.keyval == Gdk.KEY_Escape:
            self.entry.set_text("")
            self.show_lock()
            return True
        return False

    # ------------------------------------------------------- authentication --
    def on_entry_changed(self, entry):
        text = entry.get_text()
        if self.auto_submit:
            digits = re.sub(r"\D", "", text)
            if digits != text:
                entry.set_text(digits)
                return
            if len(digits) == 4:
                GLib.idle_add(self.submit)

    def submit(self):
        if not self.user:
            return False
        if self.pending is not None:
            return False
        self.pending = self.entry.get_text()
        self.entry.set_sensitive(False)
        if not self.greeter.get_in_authentication():
            self.prompted = False
            self.greeter.authenticate(self.user)
        elif self.prompted:
            self.prompted = False
            self.greeter.respond(self.pending)
        return False

    def on_prompt(self, greeter, text, kind):
        if self.pending is not None:
            self.prompted = False
            greeter.respond(self.pending)
        else:
            self.prompted = True

    def on_message(self, greeter, text, kind):
        if kind == LightDM.MessageType.ERROR:
            self.hint.set_text(text)

    def on_complete(self, greeter):
        typed = self.pending or ""
        self.pending = None
        if greeter.get_is_authenticated():
            if self.user not in self.pins or len(typed) != 4:
                no_auto = set(self.state.get("no_auto", []))
                if self.user in self.pins and len(typed) != 4:
                    no_auto.add(self.user)
                self.state["no_auto"] = sorted(no_auto)
            self.state["last"] = self.user
            save_state(self.state)
            if self.onboard:
                self.onboard.terminate()
            try:
                greeter.start_session_sync(greeter.get_default_session_hint() or "xfce")
            except GLib.Error:
                greeter.start_session_sync(None)
            return
        # wrong PIN
        self.entry.set_text("")
        self.entry.set_sensitive(True)
        self.entry.grab_focus()
        self.fails += 1
        if self.auto_submit and self.fails < 2:
            self.hint.set_text("Code PIN incorrect. Réessayez.")
        elif self.auto_submit:
            self.hint.set_text("Code PIN incorrect. Réessayez.\n(Mot de passe plus long ? Tapez-le puis appuyez sur Entrée.)")
            self.auto_submit = False
            self.entry.set_max_length(0)
        else:
            self.hint.set_text("Code PIN ou mot de passe incorrect.")
        self.prompted = False
        self.greeter.authenticate(self.user)

    # --------------------------------------------------------------- extras --
    def toggle_onboard(self, _b):
        import subprocess
        if self.onboard and self.onboard.poll() is None:
            self.onboard.terminate()
            self.onboard = None
            return
        try:
            self.onboard = subprocess.Popen(["onboard"])
        except OSError:
            self.onboard = None
        self.show_login()

    def power_menu(self, button):
        menu = Gtk.Menu()
        for text, fn, ok in (("Mettre en veille", LightDM.suspend, LightDM.get_can_suspend()),
                             ("Arrêter", LightDM.shutdown, LightDM.get_can_shutdown()),
                             ("Redémarrer", LightDM.restart, LightDM.get_can_restart())):
            it = Gtk.MenuItem(label=text)
            it.set_sensitive(ok)
            it.connect("activate", lambda _i, f=fn: f())
            menu.append(it)
        menu.show_all()
        menu.popup_at_widget(button, Gdk.Gravity.NORTH_EAST, Gdk.Gravity.SOUTH_EAST, None)


def main():
    win = Greeter()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    sys.exit(main())

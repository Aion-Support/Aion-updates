#!/usr/bin/env python3
"""Aion OS EDU — Start menu (Windows 10 layout).

Left: power / user / shortcuts strip. Middle: search box + every app A–Z.
Right: coloured tiles. Typing searches apps, settings pages and files.

Runs once per session in the background (--daemon) so it opens instantly:
/usr/bin/aion-start sends SIGUSR1 (toggle) or SIGUSR2 (open on search).
"""
import os
import signal
import sys
import time
import unicodedata

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import Gdk, Gio, GLib, Gtk, Pango  # noqa: E402

W, H = 660, 600
TILE = 98
DEFAULT_TILES = [
    {"id": "aion-cartable.desktop", "color": "#0063b1"},
    {"id": "aion-minuteur.desktop", "color": "#c62828"},
    {"id": "aion-writer.desktop", "color": "#2b579a"},
    {"id": "firefox-esr.desktop", "color": "#c1440e"},
    {"id": "gatelab.desktop", "color": "#5c2d91"},
    {"id": "turbowarp-desktop.desktop", "color": "#e65100"},
    {"id": "turbowarp-online.desktop", "color": "#e65100"},
    {"id": "aion-code.desktop", "color": "#1e1e1e"},
    {"id": "aion-calculatrice.desktop", "color": "#4c4a48"},
    {"id": "aion-parametres.desktop", "color": "#0078d7"},
    {"id": "aion-sauvegarde.desktop", "color": "#00818a"},
]
# Settings pages reachable from search: words -> (title, page id)
SETTINGS = [
    ("wifi internet réseau reseau network", "Wi-Fi", "wifi"),
    ("bluetooth casque souris", "Bluetooth", "bluetooth"),
    ("écran ecran affichage luminosité luminosite résolution resolution", "Affichage", "display"),
    ("son volume haut-parleur micro audio", "Son", "sound"),
    ("batterie énergie energie alimentation économiseur", "Alimentation et batterie", "power"),
    ("fond d'écran fond ecran arrière-plan wallpaper image", "Arrière-plan", "background"),
    ("pin mot de passe code connexion compte", "Options de connexion", "signin"),
    ("heure date horloge fuseau", "Date et heure", "datetime"),
    ("texte taille police dyslexie contraste lecture voix", "Accessibilité", "a11y"),
    ("mise à jour mise a jour update", "Mises à jour", "update"),
    ("restaurer réinitialiser reinitialiser récupération sauvegarde", "Récupération", "recovery"),
    ("bios démarrage demarrage", "Démarrage avancé", "recovery"),
    ("imprimante impression", "Imprimantes", "printers"),
    ("stockage disque espace", "Stockage", "storage"),
    ("informations à propos a propos pc ordinateur", "À propos", "about"),
    ("avion mode avion", "Mode Avion", "airplane"),
    ("veilleuse nuit", "Veilleuse", "display"),
]


def fold(s):
    """Lower case without accents, for searching."""
    s = unicodedata.normalize("NFKD", s.lower())
    return "".join(c for c in s if not unicodedata.combining(c))


class StartMenu(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL, title="Démarrer")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_resizable(False)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_default_size(W, H)
        self.get_style_context().add_class("aion-start")
        self.connect("delete-event", lambda *a: self.hide_menu() or True)
        self.connect("key-press-event", self.on_key)
        self.connect("focus-out-event", self.on_focus_out)
        self.apps = []
        self.apps_stamp = None
        self.shown_at = 0
        self.file_index = []
        self.file_index_at = 0

        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(root)
        root.pack_start(self.build_strip(), False, False, 0)

        middle = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        middle.set_size_request(290, -1)
        self.search = Gtk.SearchEntry(placeholder_text="Tapez ici pour rechercher")
        self.search.get_style_context().add_class("aion-start-search")
        self.search.set_margin_start(10)
        self.search.set_margin_end(10)
        self.search.set_margin_top(10)
        self.search.set_margin_bottom(6)
        self.search.connect("search-changed", lambda *a: self.refresh_list())
        self.search.connect("activate", self.on_activate_first)
        middle.pack_start(self.search, False, False, 0)
        sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.listbox.get_style_context().add_class("aion-start-list")
        self.listbox.connect("row-activated", self.on_row)
        sc.add(self.listbox)
        middle.pack_start(sc, True, True, 0)
        root.pack_start(middle, False, False, 0)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        right.get_style_context().add_class("aion-start-tiles")
        head = A.label("Aion OS EDU", "aion-start-tilehead")
        head.set_margin_start(14)
        head.set_margin_top(14)
        head.set_margin_bottom(8)
        right.pack_start(head, False, False, 0)
        self.tiles = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3,
                                 min_children_per_line=3, column_spacing=4, row_spacing=4,
                                 homogeneous=True)
        self.tiles.set_margin_start(12)
        self.tiles.set_margin_end(12)
        self.tiles.set_valign(Gtk.Align.START)
        right.pack_start(self.tiles, True, True, 0)
        root.pack_start(right, True, True, 0)
        A.load_css(START_CSS)
        self.reload_apps()

    # ---------------------------------------------------------------- strip --
    def build_strip(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.get_style_context().add_class("aion-start-strip")
        box.set_size_request(48, -1)

        def btn(icon, tip, cb):
            b = Gtk.Button()
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.add(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR))
            b.set_tooltip_text(tip)
            b.connect("clicked", cb)
            b.get_style_context().add_class("aion-strip-btn")
            return b

        box.pack_end(btn("system-shutdown-symbolic", "Marche/Arrêt", self.power_menu), False, False, 0)
        box.pack_end(btn("emblem-system-symbolic", "Paramètres", lambda b: self.launch_cmd(["aion-parametres"])), False, False, 0)
        box.pack_end(btn("folder-pictures-symbolic", "Images", lambda b: self.open_dir("PICTURES")), False, False, 0)
        box.pack_end(btn("folder-documents-symbolic", "Documents", lambda b: self.open_dir("DOCUMENTS")), False, False, 0)
        user = btn("avatar-default-symbolic", A.full_name(), self.user_menu)
        box.pack_end(user, False, False, 0)
        return box

    def open_dir(self, which):
        d = GLib.get_user_special_dir(getattr(GLib.UserDirectory, "DIRECTORY_" + which)) or GLib.get_home_dir()
        self.launch_cmd(["xdg-open", d])

    def popup(self, widget, items):
        menu = Gtk.Menu()
        for text, cb in items:
            it = Gtk.MenuItem(label=text)
            it.connect("activate", lambda _i, f=cb: f())
            menu.append(it)
        menu.show_all()
        menu.popup_at_widget(widget, Gdk.Gravity.NORTH_EAST, Gdk.Gravity.SOUTH_WEST, None)

    def power_menu(self, button):
        self.popup(button, [
            ("Mettre en veille", lambda: self.launch_cmd(["systemctl", "suspend"])),
            ("Arrêter", lambda: self.launch_cmd(["systemctl", "poweroff"])),
            ("Redémarrer", lambda: self.launch_cmd(["systemctl", "reboot"])),
        ])

    def user_menu(self, button):
        self.popup(button, [
            ("Modifier les paramètres du compte", lambda: self.launch_cmd(["aion-parametres", "--page", "account"])),
            ("Verrouiller", lambda: self.launch_cmd(["xflock4"])),
            ("Se déconnecter", lambda: self.launch_cmd(["xfce4-session-logout", "--logout", "--fast"])),
        ])

    # ----------------------------------------------------------------- apps --
    def apps_dirs_stamp(self):
        stamp = []
        for d in GLib.get_system_data_dirs() + [GLib.get_user_data_dir()]:
            try:
                stamp.append(os.stat(os.path.join(d, "applications")).st_mtime)
            except OSError:
                pass
        return tuple(stamp)

    def reload_apps(self):
        stamp = self.apps_dirs_stamp()
        if stamp == self.apps_stamp:
            return
        self.apps_stamp = stamp
        apps = []
        for info in Gio.AppInfo.get_all():
            if not info.should_show():
                continue
            name = info.get_display_name() or info.get_name()
            keys = " ".join(filter(None, [name, info.get_description() or "",
                                          info.get_generic_name() if hasattr(info, "get_generic_name") and info.get_generic_name() else "",
                                          " ".join(info.get_keywords() if hasattr(info, "get_keywords") else [])]))
            apps.append((GLib.utf8_collate_key(name, -1), name, fold(keys), info))
        apps.sort(key=lambda a: a[0])
        self.apps = apps
        self.refresh_list()
        self.build_tiles()

    def app_row(self, name, gicon, payload, subtitle=None):
        row = Gtk.ListBoxRow()
        row.payload = payload
        box = Gtk.Box(spacing=12)
        box.set_margin_start(12)
        box.set_margin_top(5)
        box.set_margin_bottom(5)
        img = Gtk.Image.new_from_gicon(gicon, Gtk.IconSize.DND) if gicon else Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.DND)
        img.set_pixel_size(32)
        box.pack_start(img, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        lab = A.label(name)
        lab.set_ellipsize(Pango.EllipsizeMode.END)
        texts.pack_start(lab, False, False, 0)
        if subtitle:
            texts.pack_start(A.label(subtitle, "aion-dim aion-small"), False, False, 0)
        box.pack_start(texts, True, True, 0)
        row.add(box)
        return row

    def header_row(self, text):
        row = Gtk.ListBoxRow(selectable=False, activatable=False)
        row.payload = None
        lab = A.label(text, "aion-start-letter")
        lab.set_margin_start(14)
        lab.set_margin_top(8)
        row.add(lab)
        return row

    def refresh_list(self):
        for child in self.listbox.get_children():
            self.listbox.remove(child)
        q = fold(self.search.get_text().strip())
        if not q:
            letter = None
            for _k, name, _keys, info in self.apps:
                first = fold(name[:1]).upper()
                first = first if first.isalpha() else "#"
                if first != letter:
                    letter = first
                    self.listbox.add(self.header_row(letter))
                row = self.app_row(name, info.get_icon(), ("app", info))
                row.connect("button-press-event", self.on_app_button, info)
                self.listbox.add(row)
        else:
            words = q.split()
            found = [a for a in self.apps if all(w in a[2] for w in words)]
            found.sort(key=lambda a: (not fold(a[1]).startswith(q), a[0]))
            if found:
                self.listbox.add(self.header_row("Applications"))
                for _k, name, _keys, info in found[:8]:
                    self.listbox.add(self.app_row(name, info.get_icon(), ("app", info)))
            sets = [s for s in SETTINGS if all(w in fold(s[0] + " " + s[1]) for w in words)]
            if sets:
                self.listbox.add(self.header_row("Paramètres"))
                for _w, title, page in sets[:5]:
                    self.listbox.add(self.app_row(title, Gio.ThemedIcon.new("preferences-system"), ("page", page), "Paramètres"))
            files = self.find_files(words)
            if files:
                self.listbox.add(self.header_row("Fichiers"))
                for path in files[:8]:
                    f = Gio.File.new_for_path(path)
                    try:
                        icon = f.query_info("standard::icon", 0, None).get_icon()
                    except GLib.Error:
                        icon = None
                    self.listbox.add(self.app_row(os.path.basename(path), icon, ("file", path),
                                                  os.path.dirname(path).replace(GLib.get_home_dir(), "~")))
            if not (found or sets or files):
                self.listbox.add(self.header_row("Aucun résultat"))
        self.listbox.show_all()
        first = next((r for r in self.listbox.get_children() if r.payload), None)
        if first and q:
            self.listbox.select_row(first)

    def find_files(self, words):
        """Search file names in the user's folders (index kept 60 s)."""
        if time.monotonic() - self.file_index_at > 60:
            home = GLib.get_home_dir()
            idx = []
            for top in ("Bureau", "Desktop", "Documents", "Téléchargements", "Downloads", "Images", "Musique", "Vidéos"):
                base = os.path.join(home, top)
                for dirpath, dirnames, filenames in os.walk(base):
                    dirnames[:] = [d for d in dirnames if not d.startswith(".")]
                    for fn in filenames + dirnames:
                        if not fn.startswith("."):
                            idx.append((fold(fn), os.path.join(dirpath, fn)))
                    if len(idx) > 20000:
                        break
            self.file_index, self.file_index_at = idx, time.monotonic()
        return [p for name, p in self.file_index if all(w in name for w in words)]

    # ---------------------------------------------------------------- tiles --
    def build_tiles(self):
        for c in self.tiles.get_children():
            self.tiles.remove(c)
        by_id = {a[3].get_id(): a[3] for a in self.apps}
        for t in A.load_json("start-tiles.json", DEFAULT_TILES):
            info = by_id.get(t.get("id"))
            if not info:
                continue
            b = Gtk.Button()
            b.set_size_request(TILE, TILE)
            b.get_style_context().add_class("aion-tile")
            prov = Gtk.CssProvider()
            prov.load_from_data(("button { background: %s; }" % t.get("color", "#0078d7")).encode())
            b.get_style_context().add_provider(prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            img = Gtk.Image.new_from_gicon(info.get_icon(), Gtk.IconSize.DIALOG) if info.get_icon() else Gtk.Image()
            img.set_pixel_size(40)
            img.set_vexpand(True)
            v.pack_start(img, True, True, 0)
            lab = A.label(info.get_display_name(), "aion-tile-label")
            lab.set_ellipsize(Pango.EllipsizeMode.END)
            v.pack_end(lab, False, False, 0)
            b.add(v)
            b.connect("clicked", lambda _b, i=info: self.launch_app(i))
            b.connect("button-press-event", self.on_tile_button, info)
            self.tiles.add(b)
        self.tiles.show_all()

    def tiles_list(self):
        return list(A.load_json("start-tiles.json", DEFAULT_TILES))

    def on_app_button(self, _w, ev, info):
        if ev.button == 3:
            ids = [t["id"] for t in self.tiles_list()]
            if info.get_id() in ids:
                return False
            menu = Gtk.Menu()
            it = Gtk.MenuItem(label="Épingler à l'écran de démarrage")
            it.connect("activate", lambda *_: self.pin(info))
            menu.append(it)
            menu.show_all()
            menu.popup_at_pointer(ev)
            return True
        return False

    def on_tile_button(self, _w, ev, info):
        if ev.button == 3:
            menu = Gtk.Menu()
            it = Gtk.MenuItem(label="Détacher de l'écran de démarrage")
            it.connect("activate", lambda *_: self.unpin(info))
            menu.append(it)
            menu.show_all()
            menu.popup_at_pointer(ev)
            return True
        return False

    def pin(self, info):
        tiles = self.tiles_list()
        colors = ["#0078d7", "#107c10", "#5c2d91", "#c1440e", "#00818a", "#b4009e"]
        tiles.append({"id": info.get_id(), "color": colors[len(tiles) % len(colors)]})
        A.save_json("start-tiles.json", tiles)
        self.build_tiles()

    def unpin(self, info):
        A.save_json("start-tiles.json", [t for t in self.tiles_list() if t["id"] != info.get_id()])
        self.build_tiles()

    # --------------------------------------------------------------- launch --
    def launch_app(self, info):
        self.hide_menu()
        try:
            info.launch([], Gdk.Display.get_default().get_app_launch_context())
        except GLib.Error:
            pass

    def launch_cmd(self, cmd):
        self.hide_menu()
        A.spawn(cmd)

    def activate_payload(self, payload):
        if not payload:
            return
        kind, val = payload
        if kind == "app":
            self.launch_app(val)
        elif kind == "page":
            self.launch_cmd(["aion-parametres", "--page", val])
        elif kind == "file":
            self.launch_cmd(["xdg-open", val])

    def on_row(self, _lb, row):
        self.activate_payload(row.payload)

    def on_activate_first(self, _entry):
        row = self.listbox.get_selected_row() or next((r for r in self.listbox.get_children() if r.payload), None)
        if row:
            self.activate_payload(row.payload)

    # ------------------------------------------------------------ show/hide --
    def show_menu(self, search=False):
        self.reload_apps()
        self.search.set_text("")
        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        wa = mon.get_workarea()
        h = min(H, wa.height)  # 1024x600 netbooks: the menu takes the whole height
        self.move(wa.x, wa.y + wa.height - h)
        self.resize(min(W, wa.width), h)
        self.show_all()
        self.present_with_time(Gtk.get_current_event_time() or int(time.monotonic() * 1000) & 0xFFFFFFFF)
        self.shown_at = time.monotonic()
        self.search.grab_focus()

    def hide_menu(self):
        self.hide()

    def toggle(self, search=False):
        if self.get_visible() and not search:
            self.hide_menu()
        else:
            self.show_menu(search)

    def on_focus_out(self, *_):
        if time.monotonic() - self.shown_at > 0.3:
            self.hide_menu()
        return False

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide_menu()
            return True
        if ev.keyval in (Gdk.KEY_Down, Gdk.KEY_Up) and self.search.has_focus():
            row = self.listbox.get_selected_row()
            rows = [r for r in self.listbox.get_children() if r.payload]
            if rows:
                i = rows.index(row) if row in rows else -1
                i = max(0, min(len(rows) - 1, i + (1 if ev.keyval == Gdk.KEY_Down else -1)))
                self.listbox.select_row(rows[i])
                rows[i].grab_focus()
                return True
        if not self.search.has_focus() and ev.string and ev.string.isprintable():
            self.search.grab_focus_without_selecting()
            return self.search.event(ev)
        return False


START_CSS = b"""
.aion-start { background: #2b2b2b; }
.aion-start, .aion-start label { color: #ffffff; }
.aion-start-strip { background: #1f1f1f; }
.aion-strip-btn { color: #fff; padding: 10px 0; border-radius: 0; }
.aion-strip-btn:hover { background: rgba(255,255,255,0.12); }
.aion-start-list { background: transparent; }
.aion-start-list row { border-radius: 0; }
.aion-start-list row:hover { background: rgba(255,255,255,0.10); }
.aion-start-list row:selected { background: rgba(255,255,255,0.18); }
.aion-start-letter { font-weight: bold; color: #ffffff; }
.aion-start-search { background: #ffffff; color: #000; border-radius: 0; border: 2px solid #0078d7; min-height: 30px; }
.aion-start-search image { color: #000; }
.aion-start-tilehead { color: #ffffff; font-size: 10pt; }
.aion-start .aion-dim { color: #bdbdbd; }
"""


def main():
    menu = StartMenu()
    daemon = "--daemon" in sys.argv
    GLib.unix_signal_add(GLib.PRIORITY_HIGH, signal.SIGUSR1, lambda: (menu.toggle(), True)[1])
    GLib.unix_signal_add(GLib.PRIORITY_HIGH, signal.SIGUSR2, lambda: (menu.toggle(search=True), True)[1])
    GLib.unix_signal_add(GLib.PRIORITY_HIGH, signal.SIGTERM, lambda: (Gtk.main_quit(), False)[1])
    if not daemon or "--show" in sys.argv:
        menu.show_menu("--search" in sys.argv)
    if not daemon:
        menu.connect("hide", lambda *_: Gtk.main_quit())
    else:
        # the window keeper lives here too: closing an app really quits it, and
        # forgotten images/PDF/texts close themselves (see fenetres.py)
        try:
            import fenetres
            menu.keeper = fenetres.start()
        except (ImportError, ValueError) as e:
            print("fenetres:", e, file=sys.stderr)
    Gtk.main()


if __name__ == "__main__":
    main()

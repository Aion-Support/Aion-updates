#!/bin/sh
# Aion OS EDU — last step of the installer (runs inside the new system).
# Never fails the install: every step is best-effort and logged.
LOG=/var/log/aion-install.log
exec >>"$LOG" 2>&1
echo "== Aion late install $(date)"
set -x

# 1. The pupil = the account created by the installer (first normal user)
PUPIL=$(getent passwd | awk -F: '$3>=1000 && $3<60000 && $7 !~ /nologin|false/ {print $1; exit}')
mkdir -p /etc/aion /var/lib/aion

# 2. Administrator: an "admin" account with the root password, then root is locked
if ! id admin >/dev/null 2>&1; then
    useradd -m -s /bin/bash -c "Administrateur" -G sudo,adm,lpadmin,netdev,users admin
fi
HASH=$(getent shadow root | cut -d: -f2)
case "$HASH" in
    ""|"*"|"!"*) echo "no root password set; admin keeps no password" ;;
    *) usermod -p "$HASH" admin && passwd -l root ;;
esac

# 3. The pupil logs in with a 4-digit PIN; the desktop is prepared at boot
if [ -n "$PUPIL" ]; then
    echo "$PUPIL" > /etc/aion/pin-users
    usermod -a -G users,netdev,video,audio,bluetooth,scanner "$PUPIL" || true
    gpasswd -d "$PUPIL" sudo || true
    mkdir -p /etc/lightdm/lightdm.conf.d
    printf '[Seat:*]\nautologin-user=%s\nautologin-user-timeout=0\nautologin-session=aion\n' "$PUPIL" \
        > /etc/lightdm/lightdm.conf.d/60-aion-autologin.conf
    echo "$PUPIL" > /etc/aion/autologin-user
fi

# 4. Btrfs: compression + noatime, documents in their own subvolume (@home)
#    so restore points never touch them
ROOTDEV=$(findmnt -n -o SOURCE / | sed 's/\[.*\]$//')
FSROOT=$(findmnt -n -o FSROOT /)
if [ "$(findmnt -n -o FSTYPE /)" = btrfs ]; then
    sed -i -E '/[[:space:]]btrfs[[:space:]]/ { /compress=/! s/(subvol=[^[:space:],]+|defaults)/\1,compress=zstd:1,noatime/ }' /etc/fstab
    UUID=$(blkid -s UUID -o value "$ROOTDEV")
    mkdir -p /run/aion/top
    if mount -o subvolid=5 "$ROOTDEV" /run/aion/top; then
        if [ "$FSROOT" != "/" ] && [ ! -d /run/aion/top/@home ]; then
            btrfs subvolume create /run/aion/top/@home
            cp -a --reflink=auto /home/. /run/aion/top/@home/ && find /home -mindepth 1 -maxdepth 1 -exec rm -rf {} +
            # noexec: a program downloaded into the documents can never be started (no virus from a download or a USB copy)
            echo "UUID=$UUID /home btrfs defaults,subvol=@home,compress=zstd:1,noatime,noexec,nosuid,nodev 0 0" >> /etc/fstab
        fi
        umount /run/aion/top
    fi
    # compress what the installer already wrote (saves 1-2 GB)
    timeout 900 btrfs filesystem defragment -r -czstd / || true
fi

# 5. Faster boot: initramfs with only this PC's drivers, quiet hidden boot menu
mkdir -p /etc/initramfs-tools/conf.d
echo "MODULES=dep" > /etc/initramfs-tools/conf.d/aion-dep.conf
update-initramfs -u -k all || { rm -f /etc/initramfs-tools/conf.d/aion-dep.conf; update-initramfs -u -k all; }
update-grub || true

# 6. Remove what only the USB stick needs
touch /var/lib/aion/last-auto-snapshot   # no automatic restore point for this clean-up
apt-get -y purge live-boot live-boot-initramfs-tools live-config live-config-systemd live-tools || true
apt-get -y autoremove --purge || true

# 7. First restore point: "Installation d'origine"
/usr/lib/aion/aion-snapshot create "Installation d'origine" --id origine || true
echo "== done"
exit 0

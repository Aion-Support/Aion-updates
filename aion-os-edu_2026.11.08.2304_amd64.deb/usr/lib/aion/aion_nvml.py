"""Tiny NVIDIA NVML wrapper (ctypes) used by Aion Tuning and the fan daemon.

NVML is the library behind nvidia-smi. Unlike nvidia-settings it works on
Wayland, so fan curves and clock offsets work in the normal Plasma session.
Setting fans/offsets needs root; reading works for everyone.

Every function fails soft: if the NVIDIA driver (or a feature) is missing it
returns None/False instead of raising.
"""

import ctypes

SUCCESS = 0
TEMPERATURE_GPU = 0

_lib = None
_ready = False


def _load():
    global _lib, _ready
    if _ready:
        return True
    if _lib is None:
        try:
            _lib = ctypes.CDLL("libnvidia-ml.so.1")
        except OSError:
            _lib = False
    if not _lib:
        return False
    try:
        _ready = _lib.nvmlInit_v2() == SUCCESS
    except AttributeError:
        _ready = False
    return _ready


def _call(name, *args):
    """Call an NVML function; True on success, False if it failed or doesn't exist."""
    if not _load():
        return False
    fn = getattr(_lib, name, None)
    if fn is None:
        return False
    try:
        return fn(*args) == SUCCESS
    except (OSError, ctypes.ArgumentError):
        return False


def handle(index=0):
    h = ctypes.c_void_p()
    return h if _call("nvmlDeviceGetHandleByIndex_v2", ctypes.c_uint(index), ctypes.byref(h)) else None


def available():
    return handle() is not None


def name(h=None):
    h = h or handle()
    buf = ctypes.create_string_buffer(96)
    if h and _call("nvmlDeviceGetName", h, buf, ctypes.c_uint(96)):
        return buf.value.decode(errors="replace")
    return None


def temperature(h=None):
    h = h or handle()
    t = ctypes.c_uint()
    return t.value if h and _call("nvmlDeviceGetTemperature", h, ctypes.c_int(TEMPERATURE_GPU), ctypes.byref(t)) else None


def fan_count(h=None):
    h = h or handle()
    n = ctypes.c_uint()
    return n.value if h and _call("nvmlDeviceGetNumFans", h, ctypes.byref(n)) else 0


def fan_range(h=None):
    """(min %, max %) the card accepts, e.g. (30, 100)."""
    h = h or handle()
    lo, hi = ctypes.c_uint(), ctypes.c_uint()
    if h and _call("nvmlDeviceGetMinMaxFanSpeed", h, ctypes.byref(lo), ctypes.byref(hi)):
        return lo.value, hi.value
    return 30, 100


def fan_speed(fan, h=None):
    h = h or handle()
    s = ctypes.c_uint()
    return s.value if h and _call("nvmlDeviceGetFanSpeed_v2", h, ctypes.c_uint(fan), ctypes.byref(s)) else None


def set_fan(fan, pct, h=None):
    h = h or handle()
    lo, hi = fan_range(h)
    pct = int(max(lo, min(hi, pct)))
    return bool(h) and _call("nvmlDeviceSetFanSpeed_v2", h, ctypes.c_uint(fan), ctypes.c_uint(pct))


def fans_auto(h=None):
    """Give every fan back to the card's own automatic control."""
    h = h or handle()
    ok = True
    for i in range(fan_count(h)):
        ok = _call("nvmlDeviceSetDefaultFanSpeed_v2", h, ctypes.c_uint(i)) and ok
    return ok


def _offset_range(fn, h):
    lo, hi = ctypes.c_int(), ctypes.c_int()
    return (lo.value, hi.value) if h and _call(fn, h, ctypes.byref(lo), ctypes.byref(hi)) else None


def core_offset_range(h=None):
    return _offset_range("nvmlDeviceGetGpcClkMinMaxVfOffset", h or handle())


def mem_offset_range(h=None):
    return _offset_range("nvmlDeviceGetMemClkMinMaxVfOffset", h or handle())


def _get_offset(fn, h):
    v = ctypes.c_int()
    return v.value if h and _call(fn, h, ctypes.byref(v)) else None


def core_offset(h=None):
    return _get_offset("nvmlDeviceGetGpcClkVfOffset", h or handle())


def mem_offset(h=None):
    return _get_offset("nvmlDeviceGetMemClkVfOffset", h or handle())


def set_core_offset(mhz, h=None):
    h = h or handle()
    return bool(h) and _call("nvmlDeviceSetGpcClkVfOffset", h, ctypes.c_int(int(mhz)))


def set_mem_offset(mhz, h=None):
    h = h or handle()
    return bool(h) and _call("nvmlDeviceSetMemClkVfOffset", h, ctypes.c_int(int(mhz)))


def power_usage(h=None):
    """Current board power draw in watts (None if unknown)."""
    h = h or handle()
    mw = ctypes.c_uint()
    return mw.value / 1000.0 if h and _call("nvmlDeviceGetPowerUsage", h, ctypes.byref(mw)) else None

#!/usr/bin/env python3
"""Aion OS EDU — Sauvegarde du Cartable sur clé USB, en un clic.

Copies ~/Documents/Cartable to <clé>/Sauvegardes Aion/<prénom>/Cartable
(only what changed since last time, so the second backup is fast).
"""
import os
import re
import subprocess
import sys
import threading

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import Gio, GLib, Gtk  # noqa: E402


def cartable():
    docs = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOCUMENTS) or os.path.join(GLib.get_home_dir(), "Documents")
    return os.path.join(docs, "Cartable")


class Backup(Gtk.Window):
    def __init__(self):
        super().__init__(title="Sauvegarde du Cartable")
        self.set_icon_name("aion-sauvegarde")
        self.set_default_size(520, 300)
        A.load_css()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_border_width(22)
        self.add(box)
        box.pack_start(A.label("Sauvegarder le Cartable", "aion-title"), False, False, 0)
        box.pack_start(A.label("Copie tous vos documents de classe sur une clé USB.", "aion-dim"), False, False, 0)
        self.combo = Gtk.ComboBoxText()
        box.pack_start(self.combo, False, False, 6)
        self.status = A.label("", wrap=True)
        box.pack_start(self.status, False, False, 0)
        self.bar = Gtk.ProgressBar(show_text=True)
        self.bar.set_no_show_all(True)
        box.pack_start(self.bar, False, False, 0)
        self.go = Gtk.Button(label="Sauvegarder")
        self.go.get_style_context().add_class("aion-blue")
        self.go.set_halign(Gtk.Align.END)
        self.go.connect("clicked", self.start)
        box.pack_end(self.go, False, False, 0)
        self.monitor = Gio.VolumeMonitor.get()
        for sig in ("mount-added", "mount-removed"):
            self.monitor.connect(sig, lambda *_: self.refresh())
        self.refresh()
        self.show_all()

    def refresh(self):
        self.combo.remove_all()
        self.mounts = []
        for m in self.monitor.get_mounts():
            root = m.get_root().get_path()
            if root and m.can_unmount() and not root.startswith("/run/user") and os.access(root, os.W_OK):
                self.mounts.append((m, root))
                self.combo.append_text(f"{m.get_name()}  ({root})")
        if self.mounts:
            self.combo.set_active(0)
            self.status.set_text("")
            self.go.set_sensitive(True)
        else:
            self.status.set_text("Branchez une clé USB…")
            self.go.set_sensitive(False)

    def start(self, _b):
        i = self.combo.get_active()
        if i < 0:
            return
        mount, root = self.mounts[i]
        src = cartable()
        if not os.path.isdir(src):
            self.status.set_text("Le Cartable est introuvable (Documents/Cartable).")
            return
        dest = os.path.join(root, "Sauvegardes Aion", A.full_name(), "Cartable")
        os.makedirs(dest, exist_ok=True)
        self.go.set_sensitive(False)
        self.bar.show()
        self.bar.set_fraction(0)
        self.status.set_text("Copie en cours… ne retirez pas la clé.")
        threading.Thread(target=self.copy, args=(src, dest, mount), daemon=True).start()

    def copy(self, src, dest, mount):
        # FAT/exFAT keys: no owners/permissions, 2 s time precision
        cmd = ["rsync", "-rt", "--modify-window=2", "--info=progress2", "--no-inc-recursive", src + "/", dest + "/"]
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                m = re.search(r"(\d+)%", line)
                if m:
                    GLib.idle_add(self.bar.set_fraction, int(m.group(1)) / 100)
            code = p.wait()
        except OSError as e:
            code, line = 1, str(e)
        subprocess.run(["sync"])
        GLib.idle_add(self.finished, code, dest)

    def finished(self, code, dest):
        self.bar.set_fraction(1 if code == 0 else 0)
        self.go.set_sensitive(True)
        if code == 0:
            self.status.set_markup("<b>Sauvegarde terminée.</b> Vous pouvez retirer la clé.\n" + GLib.markup_escape_text(dest))
            self.status.get_style_context().add_class("aion-ok")
        else:
            self.status.set_text("La copie a échoué (clé pleine ou retirée ?).")
            self.status.get_style_context().add_class("aion-error")
        return False


def main():
    win = Backup()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

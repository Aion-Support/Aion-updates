#!/usr/bin/env python3
"""Aion OS EDU — Minuteur visuel: a red disk that empties as time passes (like a Time Timer).

Big buttons for 1, 2, 5, 10, 15, 20 and 30 minutes. Calm: no blinking, no animation
other than the disk slowly shrinking; a soft chime at the end, then « C'est fini ! ».
"""
import math
import os
import subprocess
import sys
import time

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import GLib, Gtk  # noqa: E402

CHIME = "/usr/share/sounds/aion/minuteur-fin.wav"
CSS = b"""
.mn-big { font-size: 26pt; font-weight: 700; }
.mn-btn { font-size: 15pt; min-width: 64px; min-height: 48px; }
"""


class Timer(Gtk.Window):
    def __init__(self):
        super().__init__(title="Minuteur")
        self.set_icon_name("aion-minuteur")
        A.fit_window(self, 520, 640)
        A.load_css(CSS)
        self.total = 5 * 60
        self.left = self.total
        self.running = False
        self.end_at = 0
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_border_width(18)
        self.add(box)
        self.area = Gtk.DrawingArea()
        self.area.set_size_request(320, 320)
        self.area.connect("draw", self.on_draw)
        box.pack_start(self.area, True, True, 0)
        self.label = A.label("", "mn-big", xalign=0.5)
        box.pack_start(self.label, False, False, 0)
        grid = Gtk.FlowBox(max_children_per_line=7, min_children_per_line=4, selection_mode=Gtk.SelectionMode.NONE,
                           homogeneous=True, column_spacing=8, row_spacing=8)
        for m in (1, 2, 5, 10, 15, 20, 30):
            b = Gtk.Button(label=f"{m} min")
            b.get_style_context().add_class("mn-btn")
            b.connect("clicked", lambda _b, m=m: self.set_minutes(m))
            grid.add(b)
        box.pack_start(grid, False, False, 0)
        row = Gtk.Box(spacing=10, homogeneous=True)
        self.go = Gtk.Button(label="▶  Démarrer")
        self.go.get_style_context().add_class("mn-btn")
        self.go.get_style_context().add_class("aion-blue")
        self.go.connect("clicked", self.toggle)
        reset = Gtk.Button(label="↺  Recommencer")
        reset.get_style_context().add_class("mn-btn")
        reset.connect("clicked", lambda _b: self.set_minutes(self.total // 60))
        row.pack_start(self.go, True, True, 0)
        row.pack_start(reset, True, True, 0)
        box.pack_start(row, False, False, 0)
        self.refresh()
        GLib.timeout_add(500, self.tick)
        self.show_all()

    def set_minutes(self, m):
        self.total = self.left = m * 60
        self.running = False
        self.go.set_label("▶  Démarrer")
        self.refresh()

    def toggle(self, _b):
        if self.left <= 0:
            self.left = self.total
        self.running = not self.running
        if self.running:
            self.end_at = time.monotonic() + self.left
        self.go.set_label("⏸  Pause" if self.running else "▶  Continuer")
        self.refresh()

    def tick(self):
        if self.running:
            self.left = max(0, self.end_at - time.monotonic())
            if self.left <= 0:
                self.running = False
                self.go.set_label("▶  Démarrer")
                if os.path.exists(CHIME):
                    for player in (["pw-play", CHIME], ["aplay", "-q", CHIME]):
                        try:
                            subprocess.Popen(player, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            break
                        except OSError:
                            continue
            self.refresh()
        return True

    def refresh(self):
        s = int(math.ceil(self.left))
        self.label.set_text("C'est fini !" if s <= 0 and not self.running and self.total and self.left == 0
                            else f"{s // 60}:{s % 60:02d}")
        self.area.queue_draw()

    def on_draw(self, w, cr):
        width, height = w.get_allocated_width(), w.get_allocated_height()
        r = min(width, height) / 2 - 8
        cx, cy = width / 2, height / 2
        cr.set_source_rgb(0.96, 0.96, 0.96)
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.fill()
        frac = self.left / 3600.0 if self.total > 0 else 0  # one full disk = 60 minutes, like a Time Timer
        frac = min(frac, 1.0)
        if frac > 0:
            cr.set_source_rgb(0.85, 0.15, 0.15)
            cr.move_to(cx, cy)
            cr.arc(cx, cy, r, -math.pi / 2, -math.pi / 2 + 2 * math.pi * frac)
            cr.close_path()
            cr.fill()
        cr.set_source_rgb(0.2, 0.2, 0.2)
        cr.set_line_width(2)
        for i in range(12):
            a = -math.pi / 2 + i * math.pi / 6
            cr.move_to(cx + (r - 14) * math.cos(a), cy + (r - 14) * math.sin(a))
            cr.line_to(cx + r * math.cos(a), cy + r * math.sin(a))
        cr.stroke()
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.stroke()
        cr.arc(cx, cy, 8, 0, 2 * math.pi)
        cr.fill()
        return False


def main():
    win = Timer()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

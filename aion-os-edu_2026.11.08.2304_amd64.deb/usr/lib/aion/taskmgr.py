#!/usr/bin/env python3
"""Aion OS EDU — Gestionnaire des tâches (Windows 10 style).

Processus: apps and background processes with CPU and memory, « Fin de tâche ».
Performance: live graphs for the processor, memory, disk and network.
Démarrage: programs started at login, with Activer / Désactiver.
Ctrl+Maj+Échap or Ctrl+Alt+Suppr opens it.
"""
import collections
import glob
import os
import signal
import sys
import time

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
import psutil  # noqa: E402
from gi.repository import GLib, Gtk  # noqa: E402

CSS = b"""
.tm-head { font-size: 15pt; font-weight: 300; }
.tm-big { font-size: 20pt; font-weight: 300; }
.tm-side row { padding: 8px 10px; }
.tm-side row:selected { background: #cce8ff; color: #000; }
"""
HISTORY = 60


class Graph(Gtk.DrawingArea):
    def __init__(self, color=(0.07, 0.49, 0.85)):
        super().__init__()
        self.values = collections.deque([0.0] * HISTORY, maxlen=HISTORY)
        self.color = color
        self.set_size_request(-1, 220)
        self.connect("draw", self.on_draw)

    def push(self, v):
        self.values.append(max(0.0, min(1.0, v)))
        self.queue_draw()

    def on_draw(self, _w, cr):
        w, h = self.get_allocated_width(), self.get_allocated_height()
        r, g, b = self.color
        cr.set_source_rgb(1, 1, 1)
        cr.paint()
        cr.set_source_rgba(r, g, b, 0.18)
        cr.set_line_width(1)
        for i in range(1, 10):
            cr.move_to(0, h * i / 10)
            cr.line_to(w, h * i / 10)
        cr.stroke()
        step = w / (HISTORY - 1)
        cr.move_to(0, h)
        for i, v in enumerate(self.values):
            cr.line_to(i * step, h - v * h)
        cr.line_to(w, h)
        cr.close_path()
        cr.set_source_rgba(r, g, b, 0.15)
        cr.fill_preserve()
        cr.set_source_rgb(r, g, b)
        cr.set_line_width(1.5)
        cr.stroke()
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.stroke()


class TaskManager(Gtk.Window):
    def __init__(self):
        super().__init__(title="Gestionnaire des tâches")
        self.set_icon_name("aion-taskmgr")
        A.fit_window(self, 820, 600)
        A.load_css(CSS)
        nb = Gtk.Notebook()
        self.add(nb)
        nb.append_page(self.build_processes(), Gtk.Label(label="Processus"))
        nb.append_page(self.build_performance(), Gtk.Label(label="Performance"))
        nb.append_page(self.build_startup(), Gtk.Label(label="Démarrage"))
        self.prev_disk = psutil.disk_io_counters()
        self.prev_net = psutil.net_io_counters()
        self.prev_t = time.monotonic()
        psutil.cpu_percent(None)
        for p in psutil.process_iter():
            try:
                p.cpu_percent(None)
            except psutil.Error:
                pass
        self.update()
        GLib.timeout_add_seconds(1, self.update)
        self.show_all()

    # ----------------------------------------------------------- processes --
    def build_processes(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        # name, cpu text, mem text, pid, cpu sort, mem sort, is-app
        self.store = Gtk.ListStore(str, str, str, int, float, float, str)
        self.sorted = Gtk.TreeModelSort(model=self.store)
        self.sorted.set_sort_column_id(5, Gtk.SortType.DESCENDING)
        tv = Gtk.TreeView(model=self.sorted)
        for i, (title, col, sort) in enumerate((("Nom", 0, 0), ("Processeur", 1, 4), ("Mémoire", 2, 5), ("Type", 6, 6))):
            r = Gtk.CellRendererText(xalign=1.0 if i in (1, 2) else 0.0)
            c = Gtk.TreeViewColumn(title, r, text=col)
            c.set_sort_column_id(sort)
            c.set_resizable(True)
            c.set_expand(i == 0)
            tv.append_column(c)
        self.tv = tv
        sc = Gtk.ScrolledWindow()
        sc.add(tv)
        box.pack_start(sc, True, True, 0)
        bar = Gtk.Box()
        bar.set_border_width(8)
        end = Gtk.Button(label="Fin de tâche")
        end.connect("clicked", self.end_task)
        bar.pack_end(end, False, False, 0)
        box.pack_start(bar, False, False, 0)
        return box

    def end_task(self, _b):
        model, it = self.tv.get_selection().get_selected()
        if not it:
            return
        pid, name = model[it][3], model[it][0]
        try:
            p = psutil.Process(pid)
            if p.uids().real != os.getuid():
                A.message(self, "Impossible d'arrêter « " + name + " »", "C'est un processus du système.")
                return
        except psutil.Error:
            return
        try:
            import fenetres  # windows closed and hidden first, then every process of the app
            ok = fenetres.end_app(pid)
        except (ImportError, ValueError):
            ok = None
        if ok is False:
            A.message(self, "Impossible d'arrêter « " + name + " »", "Il fait partie du bureau d'Aion.")
            return
        if ok is None:  # fallback: the process and everything it started
            procs = [p] + p.children(recursive=True)
            for q in procs:
                try:
                    q.terminate()
                except psutil.Error:
                    pass
            GLib.timeout_add_seconds(3, lambda: ([q.kill() for q in procs if q.is_running()], False)[1])
        GLib.timeout_add(1500, lambda: (self.refresh_processes(), False)[1])

    def refresh_processes(self):
        sel_pid = None
        model, it = self.tv.get_selection().get_selected()
        if it:
            sel_pid = model[it][3]
        rows = []
        ncpu = psutil.cpu_count() or 1
        me = os.getuid()
        for p in psutil.process_iter(["name", "username", "memory_info", "uids", "cmdline", "terminal"]):
            try:
                cpu = p.cpu_percent(None) / ncpu
                mem = p.info["memory_info"].rss if p.info["memory_info"] else 0
                mine = p.info["uids"] and p.info["uids"].real == me
            except psutil.Error:
                continue
            if mem == 0:
                continue
            kind = "Application" if mine else "Système"
            rows.append((p.info["name"] or "?", f"{cpu:.1f} %".replace(".", ","), A.human_bytes(mem), p.pid, cpu, float(mem), kind))
        self.store.clear()
        for r in rows:
            self.store.append(list(r))
        if sel_pid:
            for row in self.sorted:
                if row[3] == sel_pid:
                    self.tv.get_selection().select_iter(row.iter)
                    break

    # --------------------------------------------------------- performance --
    def build_performance(self):
        box = Gtk.Box()
        self.side = Gtk.ListBox()
        self.side.get_style_context().add_class("tm-side")
        self.side.set_size_request(220, -1)
        self.perf_stack = Gtk.Stack()
        self.perf = {}
        cpu_name = ""
        for line in open("/proc/cpuinfo", encoding="utf-8", errors="replace"):
            if line.startswith("model name"):
                cpu_name = line.split(":", 1)[1].strip()
                break
        for key, title, sub, color in (("cpu", "Processeur", cpu_name, (0.07, 0.49, 0.85)),
                                       ("mem", "Mémoire", A.human_bytes(psutil.virtual_memory().total), (0.55, 0.07, 0.68)),
                                       ("disk", "Disque", "", (0.30, 0.60, 0.0)),
                                       ("net", "Réseau", "", (0.75, 0.38, 0.0))):
            row = Gtk.ListBoxRow()
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            v.pack_start(A.label(title), False, False, 0)
            small = A.label("", "aion-dim aion-small")
            v.pack_start(small, False, False, 0)
            row.add(v)
            row.key = key
            self.side.add(row)
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            page.set_border_width(16)
            head = Gtk.Box()
            head.pack_start(A.label(title, "tm-head"), False, False, 0)
            head.pack_end(A.label(sub, "aion-dim"), False, False, 0)
            page.pack_start(head, False, False, 0)
            g = Graph(color)
            page.pack_start(g, False, False, 0)
            big = A.label("", "tm-big")
            page.pack_start(big, False, False, 0)
            details = A.label("", "aion-dim", wrap=True)
            page.pack_start(details, False, False, 0)
            self.perf_stack.add_named(page, key)
            self.perf[key] = (small, g, big, details)
        self.side.connect("row-selected", lambda _l, r: r and self.perf_stack.set_visible_child_name(r.key))
        self.side.select_row(self.side.get_row_at_index(0))
        box.pack_start(self.side, False, False, 0)
        box.pack_start(self.perf_stack, True, True, 0)
        return box

    def refresh_performance(self):
        now = time.monotonic()
        dt = max(0.2, now - self.prev_t)
        self.prev_t = now
        cpu = psutil.cpu_percent(None)
        freq = psutil.cpu_freq()
        small, g, big, det = self.perf["cpu"]
        small.set_text(f"{cpu:.0f} %" + (f"  {freq.current / 1000:.2f} GHz".replace(".", ",") if freq else ""))
        g.push(cpu / 100)
        big.set_text(f"Utilisation : {cpu:.0f} %")
        det.set_text(f"{psutil.cpu_count(logical=False) or '?'} cœurs, {psutil.cpu_count()} processeurs logiques — "
                     f"{len(psutil.pids())} processus — allumé depuis {self.uptime()}")
        vm = psutil.virtual_memory()
        sw = psutil.swap_memory()
        small, g, big, det = self.perf["mem"]
        used = vm.total - vm.available
        small.set_text(f"{A.human_bytes(used)} / {A.human_bytes(vm.total)} ({vm.percent:.0f} %)")
        g.push(used / vm.total)
        big.set_text(f"Utilisée : {A.human_bytes(used)}")
        det.set_text(f"Disponible : {A.human_bytes(vm.available)} — Mémoire compressée (zram) : {A.human_bytes(sw.used)} "
                     f"sur {A.human_bytes(sw.total)}")
        d = psutil.disk_io_counters()
        if d and self.prev_disk:
            rd, wr = (d.read_bytes - self.prev_disk.read_bytes) / dt, (d.write_bytes - self.prev_disk.write_bytes) / dt
            busy = min(1.0, (d.busy_time - self.prev_disk.busy_time) / (dt * 1000)) if hasattr(d, "busy_time") else 0
            small, g, big, det = self.perf["disk"]
            small.set_text(f"{busy * 100:.0f} %")
            g.push(busy)
            big.set_text(f"Lecture : {A.human_bytes(rd)}/s   Écriture : {A.human_bytes(wr)}/s")
            st = os.statvfs("/")
            det.set_text(f"Espace libre : {A.human_bytes(st.f_bavail * st.f_frsize)} sur {A.human_bytes(st.f_blocks * st.f_frsize)}")
            self.prev_disk = d
        n = psutil.net_io_counters()
        if n and self.prev_net:
            rx, tx = (n.bytes_recv - self.prev_net.bytes_recv) / dt, (n.bytes_sent - self.prev_net.bytes_sent) / dt
            small, g, big, det = self.perf["net"]
            small.set_text(f"R : {A.human_bytes(rx)}/s  E : {A.human_bytes(tx)}/s")
            g.push(min(1.0, (rx + tx) / (5 * 1024 * 1024)))
            big.set_text(f"Réception : {A.human_bytes(rx)}/s   Envoi : {A.human_bytes(tx)}/s")
            det.set_text("Échelle du graphique : 5 Mo/s")
            self.prev_net = n

    def uptime(self):
        s = int(time.time() - psutil.boot_time())
        return f"{s // 3600} h {s % 3600 // 60:02d} min"

    # ------------------------------------------------------------- startup --
    def build_startup(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.ststore = Gtk.ListStore(str, str, str)  # name, state, file id
        tv = Gtk.TreeView(model=self.ststore)
        for i, title in enumerate(("Nom", "Statut")):
            c = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
            c.set_expand(i == 0)
            tv.append_column(c)
        self.sttv = tv
        sc = Gtk.ScrolledWindow()
        sc.add(tv)
        box.pack_start(sc, True, True, 0)
        bar = Gtk.Box(spacing=6)
        bar.set_border_width(8)
        for text, enable in (("Désactiver", False), ("Activer", True)):
            b = Gtk.Button(label=text)
            b.connect("clicked", lambda _b, e=enable: self.set_startup(e))
            bar.pack_end(b, False, False, 0)
        box.pack_start(bar, False, False, 0)
        self.load_startup()
        return box

    def load_startup(self):
        self.ststore.clear()
        user_dir = os.path.join(GLib.get_user_config_dir(), "autostart")
        entries = {}
        for d in ["/etc/xdg/autostart", user_dir]:
            for path in sorted(glob.glob(os.path.join(d, "*.desktop"))):
                kf = GLib.KeyFile()
                try:
                    kf.load_from_file(path, GLib.KeyFileFlags.NONE)
                except GLib.Error:
                    continue
                def get(k, kf=kf):
                    try:
                        return kf.get_string("Desktop Entry", k)
                    except GLib.Error:
                        return ""
                if get("OnlyShowIn") and "XFCE" not in get("OnlyShowIn"):
                    continue
                if "XFCE" in get("NotShowIn") or get("NoDisplay").lower() == "true" and not get("Name"):
                    continue
                try:
                    name = kf.get_locale_string("Desktop Entry", "Name", None)
                except GLib.Error:
                    name = os.path.basename(path)
                entries[os.path.basename(path)] = (name, get("Hidden").lower() != "true")
        for fid, (name, on) in sorted(entries.items(), key=lambda e: e[1][0].lower()):
            if fid.startswith("aion-session") or fid.startswith("aion-start"):
                continue  # Aion's own session pieces are not optional
            self.ststore.append([name, "Activé" if on else "Désactivé", fid])

    def set_startup(self, enable):
        model, it = self.sttv.get_selection().get_selected()
        if not it:
            return
        fid = model[it][2]
        user_dir = os.path.join(GLib.get_user_config_dir(), "autostart")
        os.makedirs(user_dir, exist_ok=True)
        src = os.path.join(user_dir, fid) if os.path.exists(os.path.join(user_dir, fid)) else os.path.join("/etc/xdg/autostart", fid)
        kf = GLib.KeyFile()
        kf.load_from_file(src, GLib.KeyFileFlags.KEEP_COMMENTS | GLib.KeyFileFlags.KEEP_TRANSLATIONS)
        kf.set_string("Desktop Entry", "Hidden", "false" if enable else "true")
        kf.save_to_file(os.path.join(user_dir, fid))
        self.load_startup()

    def update(self):
        try:
            self.refresh_performance()
            self.refresh_processes()
        except Exception:  # noqa: BLE001 — never close the window on a read error
            pass
        return True


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    win = TaskManager()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

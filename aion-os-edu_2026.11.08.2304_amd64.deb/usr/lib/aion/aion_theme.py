"""Aion OS EDU — colours for Aion's Qt apps (Doctor, Live Sensors, Benchmark, Code).

Light, flat and square like Windows 10, with the Windows-style blue accent.
The names are the same as before, so the apps need no other change.
"""

BG = "#ffffff"        # window background
CARD = "#f3f3f3"      # cards / panels
RAISED = "#e5e5e5"    # hovered / raised elements
LINE = "#d0d0d0"      # borders and separators
TEXT = "#1a1a1a"      # main text
DIM = "#5f5f5f"       # secondary text
ACCENT = "#0078d7"    # accent blue
ACCENT2 = "#3392e0"   # lighter blue
DEEP = "#005a9e"      # deep blue (pressed, selection)
GREEN = "#107c10"
ORANGE = "#ca5010"
RED = "#c42b1c"

QSS = f"""
QWidget {{ background: {BG}; color: {TEXT}; font-size: 10pt; font-family: "Inter"; }}
QToolTip {{ background: {CARD}; color: {TEXT}; border: 1px solid {LINE}; padding: 4px; }}
QPushButton {{ background: #e1e1e1; border: 1px solid #adadad; border-radius: 0px; padding: 6px 14px; }}
QPushButton:hover {{ background: #e5f1fb; border-color: {ACCENT}; }}
QPushButton:pressed {{ background: #cce4f7; border-color: {DEEP}; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: #f0f0f0; width: 12px; }}
QScrollBar::handle:vertical {{ background: #c2c2c2; border-radius: 0px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #a6a6a6; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QTabWidget::pane {{ border: 1px solid {LINE}; border-radius: 0px; top: -1px; }}
QTabBar::tab {{ background: transparent; color: {DIM}; padding: 8px 16px; border: none; }}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox {{ background: #ffffff; border: 1px solid #7a7a7a;
    border-radius: 0px; padding: 4px 8px; selection-background-color: {ACCENT}; selection-color: #ffffff; }}
QComboBox:focus, QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{ border-color: {ACCENT}; }}
QSlider::groove:horizontal {{ height: 4px; background: #c2c2c2; border-radius: 0px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 0px; }}
QSlider::handle:horizontal {{ background: {ACCENT}; width: 8px; margin: -10px 0; border-radius: 0px; }}
"""


def fit(win, w, h):
    """Open at w x h, or maximized when the screen is smaller than that
    (1366x768 and 1024x600 laptops, 4:3 and 5:4 screens…)."""
    try:
        from PyQt6.QtCore import Qt
        from PyQt6.QtGui import QGuiApplication
        av = QGuiApplication.primaryScreen().availableGeometry()
    except Exception:
        win.resize(w, h)
        return
    if w > av.width() - 40 or h > av.height() - 40:
        win.resize(min(w, av.width()), min(h, av.height()))
        win.setWindowState(win.windowState() | Qt.WindowState.WindowMaximized)
    else:
        win.resize(w, h)


def french(app):
    """Qt's own buttons and dialogs (Oui, Non, Annuler, Enregistrer, Ouvrir…) in French."""
    try:
        from PyQt6.QtCore import QLibraryInfo, QLocale, QTranslator
        QLocale.setDefault(QLocale(QLocale.Language.French, QLocale.Country.France))
        tr = QTranslator(app)
        if tr.load("qtbase_fr", QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
            app.installTranslator(tr)
            app._aion_translator = tr  # keep it alive
    except Exception:  # noqa: BLE001 — never block an app for a translation
        pass

"""Aion OS EDU — gardien des fenêtres. Runs inside the Start menu process, so it
costs no extra process.

1. Fermer = quitter. When the last window of an app is closed, whatever the app
   left running in the background is stopped a few seconds later: the windows
   are gone first, then the processes (SIGTERM, then SIGKILL).
2. Fichiers oubliés. Images (Ristretto), PDF (Atril) and texts (Mousepad) that
   nobody has looked at for an hour of PC use close themselves; 10 minutes when
   memory is almost full. "Looked at" = active, or at least partly visible on
   screen. Time only counts while someone uses the PC (keyboard or mouse in the
   last 5 minutes), so a break closes nothing. A text with unsaved changes
   (title starting with *) is never closed.

end_app(pid) is also the Task Manager's « Fin de tâche »: it closes and hides the
app's windows first, then ends all its processes.

Settings (Paramètres → Système → Multitâche), in ~/.config/aion/settings.json:
close_quits (on by default), auto_close (off by default: young pupils may be upset by a window that disappears).
"""
import ctypes
import os
import sys
import time

import gi

gi.require_version("Wnck", "3.0")
gi.require_version("GdkX11", "3.0")
from gi.repository import Gdk, GdkX11, GLib, Wnck  # noqa: E402
import psutil  # noqa: E402

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402

GRACE = 6             # s after the last window closed before stopping what is left
KILL_AFTER = 4        # s between SIGTERM and SIGKILL
FORGOTTEN = 60 * 60   # s of PC use without looking at a viewer window
FORGOTTEN_LOW = 10 * 60
LOW_MEMORY = 0.15     # "almost full": less than 15 % of the memory available
AWAY = 5 * 60 * 1000  # ms without keyboard or mouse = nobody is using the PC
TICK = 30             # s between two checks of the forgotten windows
VIEWERS = {"ristretto", "atril", "mousepad"}
# never stopped: the desktop itself
NEVER = {"xfce4-panel", "xfdesktop", "xfwm4", "xfsettingsd", "xfce4-session", "xfce4-notifyd",
         "xfce4-power-manager", "light-locker", "nm-applet", "blueman-applet", "pipewire",
         "pipewire-pulse", "wireplumber", "dbus-daemon", "dbus-broker", "xcape", "Xorg", "systemd",
         "lightdm", "at-spi-bus-launcher", "at-spi2-registryd", "gvfsd", "polkit-gnome-authentication-agent-1"}
INTERPRETERS = ("python", "lua", "luau", "perl", "ruby", "bash", "dash", "sh", "zsh")
WINDOWS = (Wnck.WindowType.NORMAL, Wnck.WindowType.DIALOG, Wnck.WindowType.UTILITY)
Wnck.set_client_type(Wnck.ClientType.PAGER)  # our close requests count as the user's


def _settings():
    return A.load_json("settings.json", {}) or {}


def _protected(p):
    """True for processes that must never be stopped: not ours, the desktop, Aion's own daemons."""
    try:
        if p.pid <= 1 or p.pid == os.getpid() or p.uids().real != os.getuid():
            return True
        if p.name() in NEVER:
            return True
        cmd = " ".join(p.cmdline())
    except psutil.Error:
        return True
    return "/usr/lib/aion/" in cmd and not cmd.endswith(("parametres.py", "calculatrice.py", "sauvegarde.py", "taskmgr.py"))


def _exe(p):
    try:
        return p.exe()
    except psutil.Error:
        return ""


def app_root(pid, window_pids=frozenset()):
    """The process that is "the app". From a helper process (a Firefox tab, an Electron
    renderer) climb to the parent running the same program; stop at a process that has
    its own windows, at an interpreter (a pupil's Python program is not Aion Code),
    and at the desktop."""
    p = psutil.Process(pid)
    while p.pid not in window_pids:
        try:
            parent = p.parent()
        except psutil.Error:
            break
        exe = _exe(p)
        if parent is None or _protected(parent) or not exe or _exe(parent) != exe \
                or os.path.basename(exe).startswith(INTERPRETERS):
            break
        p = parent
    return p


def _tree(root, window_pids=frozenset()):
    """root and everything it started, except other apps it opened (with their own
    windows): ending Thunar must not close the photo it opened."""
    out, stack, rexe = [root], [root], _exe(root)
    while stack:
        try:
            kids = stack.pop().children()
        except psutil.Error:
            continue
        for c in kids:
            if c.pid in window_pids and _exe(c) != rexe:
                continue
            out.append(c)
            stack.append(c)
    return out


def _window_pids(scr):
    return {w.get_pid() for w in scr.get_windows() if w.get_window_type() in WINDOWS} if scr else set()


def _server_time():
    try:
        disp = Gdk.Display.get_default()
        root = disp.get_default_screen().get_root_window()
        return GdkX11.x11_get_server_time(root)
    except Exception:
        return 0


def _screen():
    scr = Wnck.Screen.get_default()
    if scr:
        scr.force_update()
    return scr


def stop_processes(procs):
    """SIGTERM now, SIGKILL whatever is still there KILL_AFTER seconds later."""
    procs = [p for p in procs if not _protected(p)]
    for p in procs:
        try:
            p.terminate()
        except psutil.Error:
            pass

    def finish():
        for p in procs:
            try:
                if p.is_running() and p.status() != psutil.STATUS_ZOMBIE:
                    p.kill()
            except psutil.Error:
                pass
        return False
    if procs:
        GLib.timeout_add_seconds(KILL_AFTER, finish)
    return len(procs)


def end_app(pid):
    """« Fin de tâche »: the app's windows are closed and hidden first, then all its
    processes are ended. Returns False if the app can't be stopped (system process)."""
    scr = _screen()
    wp = _window_pids(scr)
    try:
        root = app_root(pid, wp)
    except psutil.Error:
        return True
    if _protected(root):
        return False
    procs = _tree(root, wp)
    pids = {p.pid for p in procs}
    if scr:
        ts = _server_time()
        for w in scr.get_windows():
            if w.get_pid() in pids:
                try:
                    w.close(ts)      # ask politely (WM_DELETE_WINDOW)…
                    w.minimize()     # …and get it off the screen right away
                except Exception:
                    pass
    GLib.timeout_add(800, lambda: (stop_processes(procs), False)[1])
    return True


class _Idle:
    """Milliseconds since the last keyboard or mouse input (X screensaver extension)."""

    class Info(ctypes.Structure):
        _fields_ = [("window", ctypes.c_ulong), ("state", ctypes.c_int), ("kind", ctypes.c_int),
                    ("til_or_since", ctypes.c_ulong), ("idle", ctypes.c_ulong), ("eventMask", ctypes.c_ulong)]

    def __init__(self):
        self.ok = False
        try:
            x11 = ctypes.cdll.LoadLibrary("libX11.so.6")
            xss = ctypes.cdll.LoadLibrary("libXss.so.1")
            x11.XOpenDisplay.restype = ctypes.c_void_p
            x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
            x11.XDefaultRootWindow.restype = ctypes.c_ulong
            x11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
            xss.XScreenSaverAllocInfo.restype = ctypes.POINTER(self.Info)
            xss.XScreenSaverQueryInfo.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(self.Info)]
            self.dpy = x11.XOpenDisplay(None)
            if self.dpy:
                self.root = x11.XDefaultRootWindow(self.dpy)
                self.info = xss.XScreenSaverAllocInfo()
                self.xss = xss
                self.ok = True
        except (OSError, AttributeError):
            self.ok = False

    def ms(self):
        if not self.ok:
            return 0
        if not self.xss.XScreenSaverQueryInfo(self.dpy, self.root, self.info):
            return 0
        return self.info.contents.idle


def _memory_low():
    try:
        with open("/proc/meminfo") as f:
            m = {k: int(v.split()[0]) for k, v in (line.split(":", 1) for line in f)}
        return m["MemAvailable"] / m["MemTotal"] < LOW_MEMORY
    except (OSError, KeyError, ValueError, ZeroDivisionError):
        return False


class Keeper:
    def __init__(self):
        self.scr = _screen()
        if not self.scr:
            return
        self.pid_of = {}       # xid -> pid, remembered while the window exists
        self.unseen = {}       # xid -> seconds of PC use without being looked at
        self.idle = _Idle()
        self.last = time.monotonic()
        for w in self.scr.get_windows():
            self._opened(self.scr, w)
        self.scr.connect("window-opened", self._opened)
        self.scr.connect("window-closed", self._closed)
        self.scr.connect("active-window-changed", self._active_changed)
        GLib.timeout_add_seconds(TICK, self._tick)

    # ------------------------------------------------ 1. close = quit
    def _opened(self, _scr, w):
        if w.get_window_type() in WINDOWS:
            self.pid_of[w.get_xid()] = w.get_pid()

    def _closed(self, _scr, w):
        xid = w.get_xid()
        self.unseen.pop(xid, None)
        pid = self.pid_of.pop(xid, 0)
        if pid > 1:
            GLib.timeout_add_seconds(GRACE, self._reap, pid)

    def _reap(self, pid):
        if not _settings().get("close_quits", True):
            return False
        self.scr.force_update()
        wp = _window_pids(self.scr)
        try:
            root = app_root(pid, wp)
        except psutil.Error:
            return False         # it quit by itself: nothing to do
        if _protected(root):
            return False
        procs = _tree(root, wp)
        if any(p.pid in wp for p in procs):
            return False         # the app still has a window open
        stop_processes(procs)
        return False

    # ------------------------------------------------ 2. forgotten files
    def _active_changed(self, scr, prev):
        for w in (prev, scr.get_active_window()):
            if w is not None:
                self.unseen[w.get_xid()] = 0

    def _visible(self, w, stacked, ws):
        """At least part of w can be seen on the screen."""
        if w.is_minimized() or (ws is not None and not w.is_visible_on_workspace(ws)):
            return False
        x, y, ww, hh = w.get_client_window_geometry()
        if ww <= 0 or hh <= 0:
            return False
        above = False
        covers = []
        for o in stacked:
            if o == w:
                above = True
                continue
            if above and not o.is_minimized() and o.get_window_type() in WINDOWS + (Wnck.WindowType.DOCK,) \
                    and (ws is None or o.is_visible_on_workspace(ws)):
                covers.append(o.get_client_window_geometry())
        for i in range(5):
            for j in range(5):
                px, py = x + ww * (i + 0.5) / 5, y + hh * (j + 0.5) / 5
                if not any(cx <= px < cx + cw and cy <= py < cy + ch for cx, cy, cw, ch in covers):
                    return True
        return False

    def _tick(self):
        now = time.monotonic()
        dt, self.last = min(now - self.last, 2 * TICK), now   # monotonic: a sleeping PC adds nothing
        if not _settings().get("auto_close", False):
            self.unseen.clear()
            return True
        if self.idle.ms() > AWAY:
            return True          # nobody at the PC: time doesn't count
        self.scr.force_update()
        stacked = self.scr.get_windows_stacked()
        ws = self.scr.get_active_workspace()
        active = self.scr.get_active_window()
        limit = FORGOTTEN_LOW if _memory_low() else FORGOTTEN
        ts = None
        for w in stacked:
            app = (w.get_class_instance_name() or w.get_class_group_name() or "").lower()
            if app not in VIEWERS or w.get_window_type() != Wnck.WindowType.NORMAL:
                continue
            xid = w.get_xid()
            if w == active or self._visible(w, stacked, ws):
                self.unseen[xid] = 0
                continue
            self.unseen[xid] = self.unseen.get(xid, 0) + dt
            if self.unseen[xid] >= limit and not (w.get_name() or "").startswith("*"):
                ts = ts if ts is not None else _server_time()
                w.close(ts)      # like clicking its X: the viewer quits normally
                self.unseen[xid] = 0
        return True


def start():
    """Called once by the Start menu daemon."""
    try:
        return Keeper()
    except Exception as e:  # never take the Start menu down with us
        print("fenetres:", e, file=sys.stderr)
        return None

"""Aion OS EDU — temps d'écran: shared by the service, the login check and Paramètres.

/etc/aion/temps.conf       LIMITE=minutes per day for each pupil (0 = no limit)
                           HEURES=8-18 (allowed hours, empty = any time)
/var/lib/aion/temps.json   {"date": "2026-11-07", "minutes": {"eleve": 42}, "bonus": {"eleve": 15}}
                           (bonus = extra minutes an adult gave today)
Administrators (sudo group) are never limited.
"""
import datetime
import grp
import json
import os

CONF = "/etc/aion/temps.conf"
STATE = "/var/lib/aion/temps.json"


def conf():
    c = {"LIMITE": "0", "HEURES": ""}
    try:
        for line in open(CONF, encoding="utf-8"):
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                c[k.strip()] = v.strip().strip('"')
    except OSError:
        pass
    try:
        c["LIMITE"] = max(0, int(c["LIMITE"]))
    except ValueError:
        c["LIMITE"] = 0
    return c


def state():
    today = datetime.date.today().isoformat()
    try:
        s = json.load(open(STATE))
    except (OSError, ValueError):
        s = {}
    if s.get("date") != today:
        s = {"date": today, "minutes": {}, "bonus": {}}
    s.setdefault("bonus", {})
    return s


def save(s):
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    with open(STATE + ".tmp", "w") as f:
        json.dump(s, f)
    os.chmod(STATE + ".tmp", 0o644)
    os.replace(STATE + ".tmp", STATE)


def is_adult(user):
    try:
        return user in grp.getgrnam("sudo").gr_mem or user == "root"
    except KeyError:
        return user == "root"


def hours_ok(c, now=None):
    h = c.get("HEURES", "")
    if not h or "-" not in h:
        return True
    now = now or datetime.datetime.now()
    try:
        a, b = (int(x) for x in h.split("-", 1))
    except ValueError:
        return True
    return a <= now.hour < b


def why_blocked(user):
    """None if the pupil may use the PC now, else the message for the child."""
    if is_adult(user):
        return None
    c = conf()
    if not hours_ok(c):
        a, b = c["HEURES"].split("-", 1)
        return f"Ce n'est pas l'heure de l'ordinateur (autorisé de {a} h à {b} h). Appelle un adulte."
    st = state()
    if c["LIMITE"] and st["minutes"].get(user, 0) >= c["LIMITE"] + st.get("bonus", {}).get(user, 0):
        return "Le temps d'ordinateur est fini pour aujourd'hui. Appelle un adulte."
    return None


def add_bonus(user, minutes):
    s = state()
    s["bonus"][user] = s["bonus"].get(user, 0) + int(minutes)
    save(s)

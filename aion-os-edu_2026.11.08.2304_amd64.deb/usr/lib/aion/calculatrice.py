#!/usr/bin/env python3
"""Aion OS EDU — Calculatrice (Windows 10 style): Standard and Scientifique.

The expression is shown above the result. Keyboard works (digits, + - * / ^ ( ),
Entrée, Échap, Retour arrière, virgule or point). No eval(): a small parser.
"""
import math
import re
import sys

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import Gdk, Gtk  # noqa: E402

CSS = b"""
.calc { background: #e6e6e6; }
.calc-expr { font-size: 11pt; color: #616161; }
.calc-display { font-size: 34pt; font-weight: 600; }
.calc-mode { font-size: 15pt; font-weight: 600; }
.k { border: none; border-radius: 0; background: #f0f0f0; font-size: 13pt; min-height: 46px; }
.k:hover { background: #d4d4d4; }
.k.num { background: #fafafa; font-weight: 600; }
.k.num:hover { background: #d4d4d4; }
.k.eq { background: #8abfe6; }
.k.eq:hover { background: #0078d7; color: #fff; }
"""

FUNCS = {"sin": lambda x, d: math.sin(math.radians(x) if d else x),
         "cos": lambda x, d: math.cos(math.radians(x) if d else x),
         "tan": lambda x, d: math.tan(math.radians(x) if d else x),
         "ln": lambda x, d: math.log(x), "log": lambda x, d: math.log10(x),
         "√": lambda x, d: math.sqrt(x)}


class Parser:
    """expr := term (('+'|'-') term)* ; term := power (('×'|'÷') power)* ; power := unary ('^' power)?"""

    def __init__(self, text, degrees=True):
        self.t = re.findall(r"\d+(?:[.,]\d+)?|sin|cos|tan|ln|log|√|π|e|[-+×÷^()!%]", text)
        self.i = 0
        self.deg = degrees

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def take(self):
        tok = self.peek()
        self.i += 1
        return tok

    def parse(self):
        v = self.expr()
        if self.peek() is not None:
            raise ValueError("syntax")
        return v

    def expr(self):
        v = self.term()
        while self.peek() in ("+", "-"):
            v = v + self.term() if self.take() == "+" else v - self.term()
        return v

    def term(self):
        v = self.power()
        while self.peek() in ("×", "÷"):
            op = self.take()
            r = self.power()
            if op == "÷" and r == 0:
                raise ZeroDivisionError
            v = v * r if op == "×" else v / r
        return v

    def power(self):
        v = self.unary()
        if self.peek() == "^":
            self.take()
            return v ** self.power()
        return v

    def unary(self):
        if self.peek() == "-":
            self.take()
            return -self.unary()
        if self.peek() == "+":
            self.take()
            return self.unary()
        return self.postfix()

    def postfix(self):
        v = self.atom()
        while self.peek() in ("!", "%"):
            if self.take() == "!":
                if v < 0 or v != int(v) or v > 170:
                    raise ValueError("fact")
                v = float(math.factorial(int(v)))
            else:
                v = v / 100
        return v

    def atom(self):
        tok = self.take()
        if tok is None:
            raise ValueError("end")
        if tok in FUNCS:
            arg = self.atom()
            return FUNCS[tok](arg, self.deg)
        if tok == "(":
            v = self.expr()
            if self.peek() == ")":
                self.take()
            return v
        if tok == "π":
            return math.pi
        if tok == "e":
            return math.e
        if re.fullmatch(r"\d+(?:[.,]\d+)?", tok):
            return float(tok.replace(",", "."))
        raise ValueError(tok)


def fmt(x):
    if math.isnan(x) or math.isinf(x):
        raise ValueError("inf")
    if abs(x) >= 1e15 or (abs(x) < 1e-9 and x != 0):
        return f"{x:.10e}".replace(".", ",")
    s = f"{x:.12f}".rstrip("0").rstrip(".")
    ent, _, dec = s.partition(".")
    neg = ent.startswith("-")
    ent = ent.lstrip("-")
    groups = []
    while len(ent) > 3:
        groups.insert(0, ent[-3:])
        ent = ent[:-3]
    groups.insert(0, ent)
    return ("-" if neg else "") + " ".join(groups) + ("," + dec if dec else "")


class Calc(Gtk.Window):
    STANDARD = [["%", "CE", "C", "⌫"], ["1/x", "x²", "√", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "-"],
                ["1", "2", "3", "+"], ["±", "0", ",", "="]]
    SCIENT = [["sin", "cos", "tan", "π", "C", "⌫"], ["ln", "log", "x²", "^", "(", ")"], ["n!", "7", "8", "9", "÷", "√"],
              ["e", "4", "5", "6", "×", "1/x"], ["%", "1", "2", "3", "-", "CE"], ["±", "0", ",", "=", "+", "deg"]]

    def __init__(self):
        super().__init__(title="Calculatrice")
        self.set_icon_name("aion-calculatrice")
        self.set_default_size(330, 520)
        self.get_style_context().add_class("calc")
        A.load_css(CSS)
        self.expr = ""
        self.just_done = False
        self.deg = True
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.add(box)
        top = Gtk.Box(spacing=6)
        top.set_border_width(8)
        self.mode = Gtk.ComboBoxText()
        self.mode.append("std", "Standard")
        self.mode.append("sci", "Scientifique")
        self.mode.set_active_id("std")
        self.mode.connect("changed", lambda c: self.build_keys())
        top.pack_start(self.mode, False, False, 0)
        box.pack_start(top, False, False, 0)
        self.exprlab = A.label("", "calc-expr", xalign=1.0)
        self.exprlab.set_margin_end(12)
        self.display = A.label("0", "calc-display", xalign=1.0, selectable=True)
        self.display.set_margin_end(12)
        box.pack_start(self.exprlab, False, False, 0)
        box.pack_start(self.display, False, False, 6)
        self.keys = Gtk.Grid(column_spacing=2, row_spacing=2, column_homogeneous=True, row_homogeneous=True)
        self.keys.set_border_width(2)
        box.pack_start(self.keys, True, True, 0)
        self.connect("key-press-event", self.on_key)
        self.build_keys()
        self.show_all()

    def build_keys(self):
        for c in self.keys.get_children():
            self.keys.remove(c)
        layout = self.SCIENT if self.mode.get_active_id() == "sci" else self.STANDARD
        self.set_default_size(470 if layout is self.SCIENT else 330, 520)
        for r, row in enumerate(layout):
            for c, key in enumerate(row):
                text = ("deg" if self.deg else "rad") if key == "deg" else key
                b = Gtk.Button(label=text)
                ctx = b.get_style_context()
                ctx.add_class("k")
                if key.isdigit() or key in (",", "±"):
                    ctx.add_class("num")
                if key == "=":
                    ctx.add_class("eq")
                b.connect("clicked", lambda _b, k=key: self.press(k))
                self.keys.attach(b, c, r, 1, 1)
        self.keys.show_all()
        self.resize(*self.get_default_size())

    def refresh_display(self):
        self.exprlab.set_text(self.expr if not self.just_done else self.exprlab.get_text())
        shown = self.current_number() or "0"
        self.display.set_text(shown)

    def current_number(self):
        m = re.search(r"(\d+(?:,\d*)?)$", self.expr)
        return m.group(1) if m else (self.expr[-12:] if self.expr else "0")

    def result(self):
        try:
            text = self.expr
            text += ")" * (text.count("(") - text.count(")"))
            return fmt(Parser(text, self.deg).parse())
        except ZeroDivisionError:
            return "Division par zéro impossible"
        except (ValueError, OverflowError, IndexError):
            return "Entrée non valide"

    def press(self, k):
        if self.just_done and (k.isdigit() or k in (",", "π", "e")):
            self.expr = ""
        self.just_done = False
        if k.isdigit():
            self.expr += k
        elif k == ",":
            if not re.search(r"\d+,\d*$", self.expr):
                self.expr += "0," if not self.expr or not self.expr[-1].isdigit() else ","
        elif k in ("+", "-", "×", "÷", "^"):
            if self.expr and self.expr[-1] in "+-×÷^":
                self.expr = self.expr[:-1]
            self.expr += k
        elif k in ("(", ")", "π", "e", "%"):
            self.expr += k
        elif k == "n!":
            self.expr += "!"
        elif k in ("sin", "cos", "tan", "ln", "log"):
            self.expr += k + "("
        elif k == "√":
            self.wrap("√(", ")")
        elif k == "x²":
            self.wrap("(", ")^2")
        elif k == "1/x":
            self.wrap("1÷(", ")")
        elif k == "±":
            self.wrap("(-", ")")
        elif k == "C":
            self.expr = ""
            self.exprlab.set_text("")
        elif k == "CE":
            self.expr = re.sub(r"(\d+(?:,\d*)?)$", "", self.expr)
        elif k == "⌫":
            self.expr = self.expr[:-1]
        elif k == "deg":
            self.deg = not self.deg
            self.build_keys()
        elif k == "=":
            if not self.expr:
                return
            res = self.result()
            self.exprlab.set_text(self.expr + " =")
            self.display.set_text(res)
            self.expr = res.replace(" ", "") if res[0].isdigit() or res[0] == "-" else ""
            self.just_done = True
            return
        self.refresh_display()

    def wrap(self, before, after):
        m = re.search(r"(\d+(?:,\d*)?|π|e)$", self.expr)
        if m:
            self.expr = self.expr[:m.start()] + before + m.group(1) + after
        elif self.expr.endswith(")"):
            depth, i = 0, len(self.expr) - 1
            while i >= 0:
                depth += {")": 1, "(": -1}.get(self.expr[i], 0)
                if depth == 0:
                    break
                i -= 1
            self.expr = self.expr[:max(i, 0)] + before + self.expr[max(i, 0):] + after
        else:
            self.expr += before

    def on_key(self, _w, ev):
        name = Gdk.keyval_name(ev.keyval) or ""
        ch = ev.string or ""
        mapping = {"*": "×", "/": "÷", ".": ",", "x": "×", "X": "×"}
        if name in ("Return", "KP_Enter") or ch == "=":
            self.press("=")
        elif name == "Escape":
            self.press("C")
        elif name == "BackSpace":
            self.press("⌫")
        elif name == "Delete":
            self.press("CE")
        elif ch and (ch.isdigit() or ch in "+-*/^(),.%!xX"):
            self.press("n!" if ch == "!" else mapping.get(ch, ch))
        else:
            return False
        return True


def main():
    win = Calc()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

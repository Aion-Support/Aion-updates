#!/usr/bin/env python3
"""Aion OS EDU — Paramètres (laid out like Windows 10 Settings).

Home: search + a grid of 9 categories. Inside a category: a sidebar with its
pages on the left, the page on the right. Admin-only changes go through
/usr/lib/aion/aion-admin with the administrator password (pkexec).

  aion-parametres [--page ID]
"""
import glob
import json
import os
import re
import sys
import time

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import GLib, Gtk, Pango  # noqa: E402

CATEGORIES = [
    ("system", "Système", "Affichage, son, notifications, alimentation", "computer"),
    ("devices", "Périphériques", "Bluetooth, imprimantes, souris", "input-mouse"),
    ("network", "Réseau et Internet", "Wi-Fi, mode Avion, filtre parental", "network-wireless"),
    ("personal", "Personnalisation", "Arrière-plan, effets visuels", "preferences-desktop-wallpaper"),
    ("accounts", "Comptes", "Votre compte, code PIN, élèves", "system-users"),
    ("time", "Heure et langue", "Date, heure, langue, clavier", "preferences-system-time"),
    ("a11y", "Accessibilité", "Texte, contraste, lecture, clavier visuel", "preferences-desktop-accessibility"),
    ("privacy", "Confidentialité", "Micro, données", "preferences-system-privacy"),
    ("update", "Mise à jour et sécurité", "Mises à jour, récupération, sauvegarde", "software-update-available"),
]
SETTINGS_FILE = "settings.json"


def settings():
    return A.load_json(SETTINGS_FILE, {}) or {}


def set_setting(key, value):
    s = settings()
    s[key] = value
    A.save_json(SETTINGS_FILE, s)


# ----------------------------------------------------------------- widgets --
class Page(Gtk.Box):
    """A settings page: title, then sections of rows (Windows 10 style)."""

    def __init__(self, title):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.set_margin_start(28)
        self.set_margin_end(28)
        self.set_margin_top(18)
        self.set_margin_bottom(24)
        self.pack_start(A.label(title, "aion-title"), False, False, 6)

    def section(self, title):
        self.pack_start(A.label(title, "aion-h2"), False, False, 4)

    def text(self, text, css="aion-dim"):
        lab = A.label(text, css, wrap=True)
        self.pack_start(lab, False, False, 0)
        return lab

    def row(self, title, desc, widget):
        box = Gtk.Box(spacing=16)
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        v.pack_start(A.label(title), False, False, 0)
        if desc:
            v.pack_start(A.label(desc, "aion-dim aion-small", wrap=True), False, False, 0)
        box.pack_start(v, True, True, 0)
        widget.set_valign(Gtk.Align.CENTER)
        box.pack_end(widget, False, False, 0)
        self.pack_start(box, False, False, 4)
        return widget

    def switch(self, title, desc, active, on_change):
        sw = Gtk.Switch(active=bool(active))
        state = Gtk.Label(label="Activé" if active else "Désactivé")
        box = Gtk.Box(spacing=10)
        box.pack_start(sw, False, False, 0)
        box.pack_start(state, False, False, 0)

        def changed(s, _p):
            state.set_text("Activé" if s.get_active() else "Désactivé")
            on_change(s.get_active(), s)
        sw.connect("notify::active", changed)
        self.row(title, desc, box)
        return sw

    def slider(self, title, value, on_change, lo=0, hi=100):
        adj = Gtk.Adjustment(value=value, lower=lo, upper=hi, step_increment=5, page_increment=10)
        sc = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=adj, digits=0)
        sc.set_size_request(320, -1)
        sc.set_value_pos(Gtk.PositionType.RIGHT)
        pending = {"id": 0}

        def changed(s):
            if pending["id"]:
                GLib.source_remove(pending["id"])
            pending["id"] = GLib.timeout_add(120, lambda: (on_change(int(s.get_value())), pending.update(id=0), False)[2])
        sc.connect("value-changed", changed)
        self.pack_start(A.label(title), False, False, 0)
        self.pack_start(sc, False, False, 0)
        return sc

    def combo(self, title, desc, options, current, on_change):
        cb = Gtk.ComboBoxText()
        for key, text in options:
            cb.append(str(key), text)
        cb.set_active_id(str(current))
        cb.connect("changed", lambda c: on_change(c.get_active_id()))
        return self.row(title, desc, cb)

    def button(self, title, desc, label, callback, blue=False):
        b = Gtk.Button(label=label)
        if blue:
            b.get_style_context().add_class("aion-blue")
        b.connect("clicked", lambda *_: callback(b))
        return self.row(title, desc, b)

    def link(self, label, callback):
        b = Gtk.LinkButton(label=label, uri="aion:")
        b.set_halign(Gtk.Align.START)
        b.connect("activate-link", lambda *_: (callback(), True)[1])
        self.pack_start(b, False, False, 0)
        return b


def need_admin_note(page):
    if not A.is_admin():
        page.text("🔒 Ces réglages demandent le mot de passe administrateur (enseignant ou parent).")


def done_cb(win, ok_text):
    def cb(code, out):
        if code == 0:
            win.toast(ok_text)
        elif code in (126, 127):
            win.toast("Annulé (mot de passe administrateur requis).")
        else:
            win.toast("Échec : " + (out.strip().splitlines() or ["erreur inconnue"])[-1])
    return cb


# ------------------------------------------------------------------- pages --
def page_display(win):
    p = Page("Affichage")
    code, out = A.run(["brightnessctl", "-m"])
    if code == 0 and out.strip():
        pct = int(re.findall(r"(\d+)%", out)[0]) if re.findall(r"(\d+)%", out) else 50
        p.section("Luminosité et couleur")
        p.slider("Modifier la luminosité", pct, lambda v: A.run(["brightnessctl", "-q", "set", f"{max(v, 5)}%"]))
    else:
        p.section("Couleur")
    p.switch("Veilleuse", "Des couleurs plus chaudes le soir, moins de lumière bleue.",
             settings().get("night_light"), lambda on, _s: night_light(on))
    p.section("Mise à l'échelle et disposition")
    dpi = A.xfconf_get("xsettings", "/Xft/DPI", "120")
    p.combo("Modifier la taille du texte, des applications et d'autres éléments", None,
            [("96", "100 %"), ("108", "110 %"), ("120", "125 % (recommandé)"), ("144", "150 %")],
            dpi if dpi in ("96", "108", "120", "144") else "120",
            lambda v: A.xfconf_set("xsettings", "/Xft/DPI", v, "int"))
    p.button("Résolution, écrans multiples, orientation", None, "Paramètres d'affichage avancés",
             lambda b: A.spawn(["xfce4-display-settings"]))
    return p


def night_light(on):
    set_setting("night_light", bool(on))
    A.spawn(["/usr/lib/aion/aion-nightlight", "on" if on else "off"])


def wp_volume():
    code, out = A.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"])
    m = re.search(r"([\d.]+)", out)
    return (int(float(m.group(1)) * 100) if (code == 0 and m) else 50), "MUTED" in out


def page_sound(win):
    p = Page("Son")
    vol, muted = wp_volume()
    p.section("Sortie")
    p.slider("Volume principal", vol, lambda v: A.run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{v / 100:.2f}"]))
    p.switch("Couper le son", None, muted, lambda on, _s: A.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1" if on else "0"]))
    p.section("Entrée")
    code, out = A.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SOURCE@"])
    p.switch("Micro coupé", "Personne ne peut utiliser le micro tant qu'il est coupé.", "MUTED" in out,
             lambda on, _s: A.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "1" if on else "0"]))
    p.button("Choisir le haut-parleur, le casque, le volume de chaque application", None, "Mélangeur de volume",
             lambda b: A.spawn(["pavucontrol"]))
    return p


def page_notifications(win):
    p = Page("Notifications et actions")
    dnd = A.xfconf_get("xfce4-notifyd", "/do-not-disturb", "false") == "true"
    p.switch("Ne pas déranger", "Les notifications sont cachées, sauf les alertes importantes.", dnd,
             lambda on, _s: A.xfconf_set("xfce4-notifyd", "/do-not-disturb", "true" if on else "false", "bool"))
    p.button("Historique des notifications", None, "Ouvrir", lambda b: A.spawn(["xfce4-notifyd-config"]))
    return p


def battery_info():
    code, out = A.run(["upower", "-e"])
    bats = [x for x in out.split() if "BAT" in x]
    if not bats:
        return None
    code, out = A.run(["upower", "-i", bats[0]])
    info = {}
    for line in out.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            info[k.strip()] = v.strip()
    return info


def page_power(win):
    p = Page("Alimentation et batterie")
    bat = battery_info()
    if bat:
        state = {"charging": "en charge", "discharging": "sur batterie", "fully-charged": "chargée",
                 "pending-charge": "branché, charge en attente"}.get(bat.get("state", ""), bat.get("state", ""))
        p.section("Batterie")
        p.text(f"Niveau : {bat.get('percentage', '?')} — {state}", "")
        if bat.get("capacity"):
            p.text(f"Santé de la batterie : {bat.get('capacity')} de sa capacité d'origine")
        saver = os.path.exists("/run/aion/battery-saver")
        p.switch("Économiseur de batterie", "Baisse la luminosité et ralentit le processeur pour durer plus longtemps.",
                 saver, lambda on, _s: A.run_async(["pkexec", "/usr/lib/aion/aion-power", "on" if on else "off"]))
    else:
        p.text("Aucune batterie détectée (PC de bureau).")
    p.section("Écran et veille")
    ch = "xfce4-power-manager"
    opts_screen = [("2", "2 minutes"), ("5", "5 minutes"), ("10", "10 minutes"), ("15", "15 minutes"), ("0", "Jamais")]
    opts_sleep = [("10", "10 minutes"), ("15", "15 minutes"), ("30", "30 minutes"), ("60", "1 heure"), ("0", "Jamais")]
    if bat:
        p.combo("Sur batterie, éteindre l'écran après", None, opts_screen,
                A.xfconf_get(ch, "/xfce4-power-manager/dpms-on-battery-off", "5"),
                lambda v: A.xfconf_set(ch, "/xfce4-power-manager/dpms-on-battery-off", v, "uint"))
        p.combo("Sur batterie, mettre en veille après", None, opts_sleep,
                A.xfconf_get(ch, "/xfce4-power-manager/inactivity-on-battery", "15"),
                lambda v: A.xfconf_set(ch, "/xfce4-power-manager/inactivity-on-battery", v, "uint"))
    p.combo("Sur secteur, éteindre l'écran après", None, opts_screen,
            A.xfconf_get(ch, "/xfce4-power-manager/dpms-on-ac-off", "10"),
            lambda v: A.xfconf_set(ch, "/xfce4-power-manager/dpms-on-ac-off", v, "uint"))
    return p


def page_multitask(win):
    p = Page("Multitâche")
    s = settings()
    p.section("Fermer une application")
    p.switch("Fermer une application l'arrête complètement",
             "Quand vous fermez sa dernière fenêtre, ce qu'elle laisse tourner en arrière-plan est arrêté "
             "quelques secondes après : la mémoire est libérée.",
             s.get("close_quits", True), lambda on, _s: set_setting("close_quits", bool(on)))
    p.section("Fichiers oubliés")
    p.switch("Fermer tout seuls les fichiers oubliés",
             "Les images, PDF et textes que vous n'avez pas regardés depuis 1 heure d'utilisation du PC se "
             "ferment (10 minutes si la mémoire est presque pleine). Un texte non enregistré n'est jamais fermé.",
             s.get("auto_close", False), lambda on, _s: set_setting("auto_close", bool(on)))
    return p


def page_screentime(win):
    p = Page("Temps d'écran")
    sys.path.insert(0, "/usr/lib/aion")
    import aion_temps as T
    c = T.conf()
    p.text("Limite l'utilisation de l'ordinateur par les élèves. Quand le temps est fini, la session se "
           "verrouille avec le message « Appelle un adulte » (prévenu 5 minutes avant). Le compte "
           "administrateur n'est jamais limité.")
    state = {"limit": str(c["LIMITE"]), "hours": c["HEURES"]}

    def save(_v=None):
        A.admin(["temps", f"{state['limit']}:{state['hours']}"], done_cb(win, "Temps d'écran enregistré."))
    need_admin_note(p)
    spin = Gtk.SpinButton.new_with_range(0, 720, 5)
    spin.set_value(int(state["limit"]))
    spin.set_tooltip_text("0 = pas de limite")
    pending = {"id": 0}

    def limit_changed(sp):
        # wait until the adult stops clicking, then save once
        if pending["id"]:
            GLib.source_remove(pending["id"])
        pending["id"] = GLib.timeout_add(1200, lambda: (state.__setitem__("limit", str(sp.get_value_as_int())),
                                                         pending.__setitem__("id", 0), save(), False)[-1])
    spin.connect("value-changed", limit_changed)
    p.row("Temps maximum par jour, pour chaque élève", "En minutes (0 = pas de limite). Exemple : 90 = 1 h 30.", spin)
    p.combo("Heures autorisées", None,
            [("toujours", "À toute heure"), ("8-17", "De 8 h à 17 h"), ("8-18", "De 8 h à 18 h"), ("8-20", "De 8 h à 20 h"),
             ("9-19", "De 9 h à 19 h")],
            state["hours"] if state["hours"] in ("8-17", "8-18", "8-20", "9-19") else "toujours",
            lambda v: (state.__setitem__("hours", "" if v == "toujours" else v), save()))
    p.section("Aujourd'hui")
    used = T.state()["minutes"]
    if used:
        for user, m in sorted(used.items()):
            p.text(f"{A.full_name(user)} : {m // 60} h {m % 60:02d}" if m >= 60 else f"{A.full_name(user)} : {m} min", "")
    else:
        p.text("Personne n'a encore utilisé l'ordinateur aujourd'hui.")
    p.text("Quand le temps est fini, l'élève voit « C'est fini ! » avec un bouton « Demander plus de temps » : "
           "un adulte tape le code PIN adulte et donne 15, 30 ou 60 minutes de plus. Sinon, la session se "
           "verrouille 2 minutes après.")
    p.button("Redonner du temps", "Remet à zéro le temps utilisé aujourd'hui par tous les élèves.", "Remettre à zéro",
             lambda b: A.admin(["temps-reset"], done_cb(win, "Compteur remis à zéro.")))
    p.section("Code PIN adulte")
    p.text("Ce code à 4 chiffres ouvre toutes les pages des Paramètres sur les comptes élèves.")
    p.button("Changer le code PIN adulte", None, "Changer", lambda b: new_adult_pin(win))
    return p


def page_storage(win):
    p = Page("Stockage")
    for mount, name in (("/", "Système"), ("/home", "Documents des élèves")):
        try:
            st = os.statvfs(mount)
        except OSError:
            continue
        total, free = st.f_blocks * st.f_frsize, st.f_bavail * st.f_frsize
        if mount == "/home" and os.stat("/home").st_dev == os.stat("/").st_dev:
            continue
        p.section(name)
        bar = Gtk.LevelBar(min_value=0, max_value=1, value=(total - free) / total if total else 0)
        bar.set_size_request(-1, 14)
        p.pack_start(bar, False, False, 0)
        p.text(f"{A.human_bytes(total - free)} utilisés sur {A.human_bytes(total)} — {A.human_bytes(free)} libres")
    p.text("Les fichiers sont compressés automatiquement : le disque contient environ 30 à 50 % de plus.")
    p.section("Libérer de l'espace")
    p.button("Corbeille", "Supprime définitivement les fichiers de la corbeille.", "Vider la corbeille",
             lambda b: (A.run(["gio", "trash", "--empty"]), win.toast("Corbeille vidée.")))
    p.button("Fichiers temporaires", "Miniatures et fichiers en cache de votre compte.", "Nettoyer",
             lambda b: (A.run(["sh", "-c", 'rm -rf "$HOME/.cache/thumbnails" "$HOME/.cache/mozilla/firefox"/*/cache2']),
                        win.toast("Fichiers temporaires supprimés.")))
    return p


def read_first(path, default=""):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return default


def page_about(win):
    p = Page("À propos de")
    p.section("Caractéristiques de l'appareil")
    cpu = ""
    for line in read_first("/proc/cpuinfo").splitlines():
        if line.startswith("model name"):
            cpu = line.split(":", 1)[1].strip()
            break
    mem = re.search(r"MemTotal:\s+(\d+)", read_first("/proc/meminfo"))
    rows = [
        ("Nom de l'appareil", GLib.get_host_name()),
        ("Modèle", (read_first("/sys/class/dmi/id/sys_vendor") + " " + read_first("/sys/class/dmi/id/product_name")).strip() or "Inconnu"),
        ("Processeur", cpu or "Inconnu"),
        ("Mémoire RAM", A.human_bytes(int(mem.group(1)) * 1024) if mem else "Inconnue"),
        ("Version du BIOS", read_first("/sys/class/dmi/id/bios_version", "Inconnue") + " (" + read_first("/sys/class/dmi/id/bios_date") + ")"),
    ]
    grid = Gtk.Grid(column_spacing=24, row_spacing=6)
    for i, (k, v) in enumerate(rows):
        grid.attach(A.label(k, "aion-dim"), 0, i, 1, 1)
        grid.attach(A.label(v, selectable=True), 1, i, 1, 1)
    p.pack_start(grid, False, False, 0)
    p.section("Système")
    p.text(read_first("/etc/aion/version", "Aion OS EDU"), "")
    p.text("Basé sur Debian 13. Aucune publicité, aucune télémétrie.")
    p.section("Aide")
    p.text("En cas de problème, envoyez un message (SMS) au +33 6 60 58 02 02.", "")
    return p


def page_bluetooth(win):
    p = Page("Bluetooth et autres appareils")
    code, out = A.run(["bluetoothctl", "show"], timeout=4)
    if code != 0 or "Controller" not in out:
        p.text("Aucun adaptateur Bluetooth trouvé (ou il démarre encore, réessayez dans quelques secondes).")
    else:
        powered = "Powered: yes" in out
        p.switch("Bluetooth", None, powered,
                 lambda on, _s: A.run_async(["bluetoothctl", "power", "on" if on else "off"]))
    p.button("Ajouter un appareil", "Casque, souris, clavier, enceinte…", "Ajouter Bluetooth ou un autre appareil",
             lambda b: A.spawn(["blueman-manager"]), blue=True)
    return p


def page_printers(win):
    p = Page("Imprimantes et scanners")
    p.text("Les imprimantes récentes (Wi-Fi ou USB) sont reconnues automatiquement.")
    p.button("Ajouter ou gérer une imprimante", None, "Ouvrir", lambda b: A.spawn(["system-config-printer"]), blue=True)
    return p


def page_mouse(win):
    p = Page("Souris et pavé tactile")
    p.button("Vitesse, boutons, pavé tactile (toucher pour cliquer)", None, "Ouvrir",
             lambda b: A.spawn(["xfce4-mouse-settings"]))
    return p


def page_keyboard(win):
    p = Page("Clavier")
    p.text("Disposition : Français (AZERTY). Le pavé numérique est activé au démarrage.", "")
    p.button("Raccourcis et disposition", None, "Ouvrir", lambda b: A.spawn(["xfce4-keyboard-settings"]))
    return p


def nm_active():
    code, out = A.run(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"])
    return [l.split(":") for l in out.splitlines() if l and ":loopback" not in l and ":lo" not in l]


def page_status(win):
    p = Page("État")
    act = nm_active()
    if act:
        name, kind, dev = (act[0] + ["", "", ""])[:3]
        p.section("Vous êtes connecté à Internet" if A.run(["nmcli", "-t", "networking", "connectivity"])[1].strip() == "full"
                  else "Connecté au réseau")
        p.text(f"{name} ({'Wi-Fi' if 'wireless' in kind else 'Ethernet' if 'ethernet' in kind else kind})", "")
        code, ip = A.run(["nmcli", "-g", "IP4.ADDRESS", "device", "show", dev])
        if ip.strip():
            p.text("Adresse IP : " + ip.strip().split("|")[0])
    else:
        p.section("Pas de connexion")
        p.text("Choisissez un réseau Wi-Fi dans « Wi-Fi ».")
    p.button("Réseaux enregistrés", None, "Gérer", lambda b: A.spawn(["nm-connection-editor"]))
    return p


def page_wifi(win):
    p = Page("Wi-Fi")
    code, radio = A.run(["nmcli", "radio", "wifi"])
    on = radio.strip() == "enabled"
    p.switch("Wi-Fi", None, on, lambda v, _s: (A.run(["nmcli", "radio", "wifi", "on" if v else "off"]), win.reload_later(2500)))
    if not on:
        return p
    p.section("Réseaux disponibles")
    listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    listbox.get_style_context().add_class("frame")
    p.pack_start(listbox, False, False, 0)
    status = p.text("Recherche des réseaux…")

    def fill(code, out):
        status.set_text("" if code == 0 else "Impossible de lister les réseaux.")
        seen = set()
        for line in out.splitlines():
            parts = re.split(r"(?<!\\):", line)
            if len(parts) < 4 or not parts[1] or parts[1] in seen:
                continue
            inuse, ssid, signal, sec = parts[0], parts[1].replace("\\:", ":"), parts[2], parts[3]
            seen.add(parts[1])
            row = Gtk.Box(spacing=12)
            row.set_margin_start(10)
            row.set_margin_end(10)
            row.set_margin_top(6)
            row.set_margin_bottom(6)
            sig = int(signal or 0)
            icon = "network-wireless-signal-" + ("excellent" if sig > 75 else "good" if sig > 50 else "ok" if sig > 25 else "weak")
            row.pack_start(Gtk.Image.new_from_icon_name(icon + "-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            v.pack_start(A.label(ssid), False, False, 0)
            v.pack_start(A.label(("Connecté, " if inuse == "*" else "") + ("Sécurisé" if sec and sec != "--" else "Ouvert"),
                                 "aion-dim aion-small"), False, False, 0)
            row.pack_start(v, True, True, 0)
            if inuse != "*":
                b = Gtk.Button(label="Se connecter")
                b.connect("clicked", lambda _b, s=ssid, secured=(sec and sec != "--"): wifi_connect(win, s, secured))
                row.pack_end(b, False, False, 0)
            listbox.add(row)
        listbox.show_all()
    A.run_async(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "auto"], fill, timeout=30)
    return p


def wifi_connect(win, ssid, secured):
    known = ssid in A.run(["nmcli", "-t", "-f", "NAME", "connection", "show"])[1].splitlines()
    if known:
        cmd = ["nmcli", "connection", "up", "id", ssid]
    else:
        cmd = ["nmcli", "device", "wifi", "connect", ssid]
        if secured:
            d = Gtk.Dialog(title="Se connecter à " + ssid, transient_for=win, modal=True)
            d.add_button("Annuler", Gtk.ResponseType.CANCEL)
            d.add_button("Se connecter", Gtk.ResponseType.OK)
            d.set_default_response(Gtk.ResponseType.OK)
            e = Gtk.Entry(visibility=False, activates_default=True, placeholder_text="Clé de sécurité réseau")
            box = d.get_content_area()
            box.set_spacing(8)
            box.set_border_width(12)
            box.add(A.label("Entrez la clé de sécurité du réseau (mot de passe Wi-Fi)"))
            box.add(e)
            show = Gtk.CheckButton(label="Afficher les caractères")
            show.connect("toggled", lambda c: e.set_visibility(c.get_active()))
            box.add(show)
            d.show_all()
            r = d.run()
            pw = e.get_text()
            d.destroy()
            if r != Gtk.ResponseType.OK:
                return
            cmd += ["password", pw]
    win.toast("Connexion à " + ssid + "…")
    A.run_async(cmd, lambda code, out: (win.toast("Connecté à " + ssid if code == 0 else "Échec de la connexion : mot de passe incorrect ?"),
                                        win.reload_later(500)), timeout=60)


def page_airplane(win):
    p = Page("Mode Avion")
    code, out = A.run(["nmcli", "radio", "all"])
    off = "enabled" not in out
    p.text("Coupe le Wi-Fi et le Bluetooth (en avion, ou pendant un contrôle).")

    def change(on, _s):
        if on:
            A.run(["nmcli", "radio", "all", "off"])
            A.run_async(["bluetoothctl", "power", "off"])
        else:
            A.run(["nmcli", "radio", "all", "on"])
    p.switch("Mode Avion", None, off, change)
    return p


def page_filter(win):
    p = Page("Filtre parental")
    on = os.path.exists("/etc/aion/dnsfilter.enabled")
    p.text("Bloque les sites pour adultes, la violence extrême et les arnaques, et force la recherche "
           "sécurisée (Google, Bing, YouTube, DuckDuckGo). Le filtre est appliqué à tout le PC, quel que soit le navigateur.")
    need_admin_note(p)
    p.switch("Filtre parental", "Recommandé pour les enfants.", on,
             lambda v, _s: A.admin(["dnsfilter", "on" if v else "off"], done_cb(win, "Filtre parental " + ("activé." if v else "désactivé."))))
    p.text("Réseau d'école qui bloque le filtre ? Désactivez-le le temps de vous connecter, puis réactivez-le.")
    return p


def page_background(win):
    p = Page("Arrière-plan")
    p.text("Choisissez une image")
    flow = Gtk.FlowBox(max_children_per_line=4, selection_mode=Gtk.SelectionMode.NONE, row_spacing=8, column_spacing=8)
    pics = sorted(glob.glob("/usr/share/backgrounds/aion/*.jpg") + glob.glob("/usr/share/backgrounds/aion/*.png"))
    for path in pics:
        try:
            from gi.repository import GdkPixbuf
            pix = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 160, 90, False)
        except Exception:  # noqa: BLE001
            continue
        b = Gtk.Button()
        b.add(Gtk.Image.new_from_pixbuf(pix))
        b.connect("clicked", lambda _b, f=path: set_wallpaper(win, f))
        flow.add(b)
    p.pack_start(flow, False, False, 0)

    def browse(_b):
        d = Gtk.FileChooserDialog(title="Choisir une image", transient_for=win, action=Gtk.FileChooserAction.OPEN)
        d.add_button("Annuler", Gtk.ResponseType.CANCEL)
        d.add_button("Choisir", Gtk.ResponseType.OK)
        flt = Gtk.FileFilter()
        flt.set_name("Images")
        flt.add_mime_type("image/*")
        d.add_filter(flt)
        d.set_current_folder(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir())
        if d.run() == Gtk.ResponseType.OK:
            set_wallpaper(win, d.get_filename())
        d.destroy()
    b = Gtk.Button(label="Parcourir")
    b.set_halign(Gtk.Align.START)
    b.connect("clicked", browse)
    p.pack_start(b, False, False, 0)
    return p


def set_wallpaper(win, path):
    code, out = A.run(["xfconf-query", "-c", "xfce4-desktop", "-l"])
    props = [l for l in out.splitlines() if l.endswith("/last-image")]
    if not props:
        props = ["/backdrop/screen0/monitor0/workspace0/last-image"]
    for prop in props:
        A.xfconf_set("xfce4-desktop", prop, path)
    win.toast("Arrière-plan modifié.")


def page_effects(win):
    p = Page("Couleurs et effets")
    comp = A.xfconf_get("xfwm4", "/general/use_compositing", "false") == "true"
    p.switch("Effets visuels (ombres, transparence)", "Désactivés par défaut : le PC est plus rapide sans.", comp,
             lambda on, _s: A.xfconf_set("xfwm4", "/general/use_compositing", "true" if on else "false", "bool"))
    theme = A.xfconf_get("xsettings", "/Net/ThemeName", "Aion10")
    p.switch("Mode sombre", "Fenêtres sombres, plus reposant le soir.", theme == "Aion10-Dark",
             lambda on, _s: A.xfconf_set("xsettings", "/Net/ThemeName", "Aion10-Dark" if on else "Aion10"))
    return p


def pin_dialog(win, title, need_two=True):
    d = Gtk.Dialog(title=title, transient_for=win, modal=True)
    d.add_button("Annuler", Gtk.ResponseType.CANCEL)
    d.add_button("OK", Gtk.ResponseType.OK)
    d.set_default_response(Gtk.ResponseType.OK)
    box = d.get_content_area()
    box.set_spacing(8)
    box.set_border_width(14)
    box.add(A.label("Le code PIN contient exactement 4 chiffres."))
    e1 = Gtk.Entry(visibility=False, max_length=4, input_purpose=Gtk.InputPurpose.PIN, placeholder_text="Nouveau code PIN")
    e2 = Gtk.Entry(visibility=False, max_length=4, input_purpose=Gtk.InputPurpose.PIN, placeholder_text="Confirmer le code PIN",
                   activates_default=True)
    box.add(e1)
    if need_two:
        box.add(e2)
    err = A.label("", "aion-error")
    box.add(err)
    d.show_all()
    while True:
        if d.run() != Gtk.ResponseType.OK:
            d.destroy()
            return None
        a, b = e1.get_text(), e2.get_text() if need_two else e1.get_text()
        if not re.fullmatch(r"\d{4}", a):
            err.set_text("Il faut 4 chiffres.")
        elif a != b:
            err.set_text("Les deux codes ne sont pas identiques.")
        else:
            d.destroy()
            return a


def page_account(win):
    p = Page("Vos informations")
    p.pack_start(Gtk.Image.new_from_icon_name("avatar-default", Gtk.IconSize.DIALOG), False, False, 6)
    p.pack_start(A.label(A.full_name(), "aion-h2", xalign=0.5), False, False, 0)
    p.pack_start(A.label("Administrateur" if A.is_admin() else "Compte élève (standard)", "aion-dim", xalign=0.5), False, False, 0)
    return p


def page_signin(win):
    p = Page("Options de connexion")
    p.section("Code PIN")
    p.text("Vous vous connectez avec un code PIN de 4 chiffres.")

    def change(_b):
        pin = pin_dialog(win, "Changer mon code PIN")
        if pin:
            A.run_async(["pkexec", "/usr/lib/aion/aion-pin"], done_cb(win, "Code PIN modifié."), input_text=pin + "\n")
    p.button("Changer mon code PIN", "On vous demandera votre code actuel.", "Modifier", change, blue=True)
    p.section("Verrouillage")
    p.text("Verrouillez le PC quand vous partez : touche Windows + L.")
    return p


def page_others(win):
    p = Page("Famille et autres utilisateurs")
    need_admin_note(p)
    p.section("Comptes élèves")
    for user in A.students():
        box = Gtk.Box(spacing=10)
        box.pack_start(Gtk.Image.new_from_icon_name("avatar-default", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        box.pack_start(A.label(f"{A.full_name(user)}  ({user})"), True, True, 0)
        b1 = Gtk.Button(label="Changer le code PIN")

        def set_pin(_b, u=user):
            pin = pin_dialog(win, "Code PIN de " + A.full_name(u))
            if pin:
                A.admin(["student-pin", u], done_cb(win, "Code PIN modifié."), input_text=pin + "\n")
        b1.connect("clicked", set_pin)
        b2 = Gtk.Button(label="Supprimer")

        def delete(_b, u=user):
            if A.confirm(win, "Supprimer le compte de " + A.full_name(u) + " ?",
                         "Ses documents seront aussi supprimés. Pensez à les sauvegarder avant.", "Supprimer"):
                A.admin(["student-del", u], lambda c, o: (done_cb(win, "Compte supprimé.")(c, o), win.reload_later(300)))
        b2.connect("clicked", delete)
        box.pack_end(b2, False, False, 0)
        box.pack_end(b1, False, False, 0)
        p.pack_start(box, False, False, 2)

    def add(_b):
        d = Gtk.Dialog(title="Ajouter un élève", transient_for=win, modal=True)
        d.add_button("Annuler", Gtk.ResponseType.CANCEL)
        d.add_button("Suivant", Gtk.ResponseType.OK)
        box = d.get_content_area()
        box.set_spacing(8)
        box.set_border_width(14)
        name = Gtk.Entry(placeholder_text="Prénom de l'élève", activates_default=True)
        box.add(name)
        d.set_default_response(Gtk.ResponseType.OK)
        d.show_all()
        r = d.run()
        full = name.get_text().strip()
        d.destroy()
        if r != Gtk.ResponseType.OK or not full:
            return
        import unicodedata
        login = "".join(c for c in unicodedata.normalize("NFKD", full.lower()) if c.isalnum() and c.isascii())[:24] or "eleve"
        pin = pin_dialog(win, "Code PIN de " + full)
        if pin:
            A.admin(["student-add", login, full], lambda c, o: (done_cb(win, f"Compte « {full} » créé (identifiant {login}).")(c, o),
                                                               win.reload_later(300)), input_text=pin + "\n")
    p.button("Ajouter un élève", "Chaque élève a son compte, ses documents et son code PIN.", "Ajouter", add, blue=True)
    p.section("Connexion automatique")
    auto = read_first("/etc/aion/autologin-user")
    studs = A.students()
    p.text("Au démarrage, le bureau de l'élève se prépare pendant qu'il tape son code PIN (démarrage plus rapide).")
    p.switch("Préparer le bureau au démarrage", "Pour : " + (A.full_name(auto) if auto else (A.full_name(studs[0]) if studs else "—")),
             bool(auto), lambda on, _s: A.admin(["autologin", "on" if on else "off"] + ([auto or studs[0]] if (on and (auto or studs)) else []),
                                                done_cb(win, "Réglage enregistré.")))
    return p


def page_datetime(win):
    p = Page("Date et heure")
    lab = A.label("", "aion-h2")
    p.pack_start(lab, False, False, 0)

    def tick():
        lab.set_text(GLib.DateTime.new_now_local().format("%A %e %B %Y, %H:%M").capitalize())
        return lab.get_mapped() or lab.get_parent() is not None
    tick()
    GLib.timeout_add_seconds(20, tick)
    code, out = A.run(["timedatectl", "show", "-p", "NTP", "-p", "Timezone"])
    ntp = "NTP=yes" in out
    tz = re.search(r"Timezone=(.*)", out)
    p.switch("Régler l'heure automatiquement", "Par Internet (recommandé).", ntp,
             lambda on, _s: A.run_async(["timedatectl", "set-ntp", "true" if on else "false"]))
    p.text("Fuseau horaire : " + (tz.group(1) if tz else "Europe/Paris"), "")
    return p


def page_language(win):
    p = Page("Langue et clavier")
    p.text("Langue d'affichage : Français (France)", "")
    p.text("Clavier : Français (AZERTY)", "")
    p.button("Disposition du clavier", None, "Modifier", lambda b: A.spawn(["xfce4-keyboard-settings"]))
    return p


def page_a11y(win):
    p = Page("Affichage et texte")
    dpi = A.xfconf_get("xsettings", "/Xft/DPI", "120")
    p.combo("Taille du texte", None, [("96", "100 %"), ("108", "110 %"), ("120", "125 %"), ("144", "150 %")],
            dpi if dpi in ("96", "108", "120", "144") else "120",
            lambda v: A.xfconf_set("xsettings", "/Xft/DPI", v, "int"))
    theme = A.xfconf_get("xsettings", "/Net/ThemeName", "Aion10")
    p.switch("Contraste élevé", "Texte et contours très marqués.", theme == "HighContrast",
             lambda on, _s: A.xfconf_set("xsettings", "/Net/ThemeName", "HighContrast" if on else "Aion10"))
    font = A.xfconf_get("xsettings", "/Gtk/FontName", "Inter 10")
    p.switch("Police adaptée à la dyslexie", "OpenDyslexic : des lettres plus faciles à distinguer.", "OpenDyslexic" in font,
             lambda on, _s: A.xfconf_set("xsettings", "/Gtk/FontName", "OpenDyslexic 10" if on else "Inter 10"))
    size = A.xfconf_get("xsettings", "/Gtk/CursorThemeSize", "24")
    p.combo("Taille du pointeur de la souris", None, [("24", "Normale"), ("32", "Grande"), ("48", "Très grande")],
            size if size in ("24", "32", "48") else "24",
            lambda v: A.xfconf_set("xsettings", "/Gtk/CursorThemeSize", v, "int"))
    p.switch("Veilleuse", "Couleurs plus chaudes le soir.", settings().get("night_light"), lambda on, _s: night_light(on))
    return p


def page_reading(win):
    p = Page("Lecture à voix haute")
    p.text("Sélectionnez un texte (dans un site, un document, un PDF…), puis appuyez sur Ctrl + Alt + L : "
           "l'ordinateur le lit à voix haute. Appuyez encore pour arrêter.", "")
    cfg = A.load_json("lire.json", {"rate": 100}) or {"rate": 100}
    p.slider("Vitesse de la voix (%)", cfg.get("rate", 100), lambda v: A.save_json("lire.json", {"rate": v}), 50, 200)
    p.button("Essayer", None, "Écouter un exemple",
             lambda b: A.spawn(["aion-lire", "--text", "Bonjour ! Je lis à voix haute le texte que tu sélectionnes."]), blue=True)
    return p


def page_vkbd(win):
    p = Page("Clavier visuel et loupe")
    running = A.run(["pgrep", "-u", str(os.getuid()), "-x", "onboard"])[0] == 0
    p.switch("Clavier visuel", "Un clavier à l'écran, utilisable à la souris ou au doigt. Raccourci : Windows + Ctrl + O.",
             running, lambda on, _s: A.spawn(["onboard"]) if on else A.run(["pkill", "-u", str(os.getuid()), "-x", "onboard"]))
    comp = A.xfconf_get("xfwm4", "/general/use_compositing", "false") == "true"
    p.switch("Loupe", "Une fois activée : maintenez Alt et tournez la molette de la souris pour zoomer.", comp,
             lambda on, _s: A.xfconf_set("xfwm4", "/general/use_compositing", "true" if on else "false", "bool"))
    return p


def page_privacy(win):
    p = Page("Micro")
    p.text("Aion OS EDU n'envoie aucune donnée : pas de télémétrie, pas de publicité, pas de compte en ligne obligatoire.", "")
    code, out = A.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SOURCE@"])
    p.switch("Micro autorisé", None, "MUTED" not in out,
             lambda on, _s: A.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "0" if on else "1"]))
    return p


def page_update(win):
    p = Page("Mises à jour")
    last = read_first("/var/lib/aion/last-update", "")
    p.section("Vous êtes à jour" if last else "Mises à jour automatiques")
    if last:
        p.text("Dernière installation : " + last)
    p.text("Les mises à jour de sécurité se téléchargent en arrière-plan et s'installent quand vous éteignez le PC : "
           "jamais au milieu d'un cours. Un point de restauration est créé avant chaque installation.")
    status = p.text("")

    def check(b):
        b.set_sensitive(False)
        status.set_text("Installation des mises à jour… (cela peut prendre plusieurs minutes)")

        def done(code, out):
            b.set_sensitive(True)
            status.set_text("Mises à jour installées." if code == 0 else
                            "Annulé." if code in (126, 127) else "Échec : vérifiez la connexion Internet.")
        A.admin(["update"], done)
    need_admin_note(p)
    p.button("Installer les mises à jour maintenant", None, "Rechercher des mises à jour", check, blue=True)
    return p


def page_recovery(win):
    p = Page("Récupération")
    need_admin_note(p)
    snaps = []
    try:
        with open("/var/lib/aion/snapshots.json", encoding="utf-8") as f:
            snaps = json.load(f)
    except (OSError, ValueError):
        pass
    p.section("Points de restauration")
    p.text("Revenir en arrière remet le système comme il était à cette date. Les documents des élèves ne sont pas touchés.")
    if not snaps:
        p.text("Aucun point de restauration pour l'instant.")
    for s in sorted(snaps, key=lambda x: "0" if x.get("id") == "origine" else x.get("id", ""), reverse=True)[:8]:
        box = Gtk.Box(spacing=10)
        box.pack_start(A.label(f"{s.get('label', '')} — {s.get('date', '')}"), True, True, 0)
        b = Gtk.Button(label="Restaurer")

        def restore(_b, sid=s["id"], lab=s.get("label", "")):
            if A.confirm(win, "Restaurer « " + lab + " » ?",
                         "Le PC redémarre ensuite. Les documents sont conservés. Les applications et réglages installés après cette date disparaissent.",
                         "Restaurer et redémarrer"):
                A.admin(["snapshot-restore", sid], lambda c, o: (A.spawn(["systemctl", "reboot"]) if c == 0 else done_cb(win, "")(c, o)))
        b.connect("clicked", restore)
        box.pack_end(b, False, False, 0)
        p.pack_start(box, False, False, 2)
    p.button("Créer un point de restauration maintenant", None, "Créer",
             lambda b: A.admin(["snapshot-create", "Point créé à la main"], lambda c, o: (done_cb(win, "Point de restauration créé.")(c, o),
                                                                                       win.reload_later(300))))
    p.section("Réinitialiser ce PC")
    p.text("Revenir à l'installation d'origine, en conservant les documents des élèves.")

    def reset(_b):
        orig = next((s for s in snaps if s.get("id") == "origine"), None)
        if not orig:
            win.toast("Le point « Installation d'origine » est introuvable.")
            return
        if A.confirm(win, "Réinitialiser ce PC ?", "Toutes les applications et tous les réglages reviennent à l'installation. "
                     "Les documents des élèves sont conservés. Le PC redémarre.", "Réinitialiser"):
            A.admin(["snapshot-restore", "origine"], lambda c, o: (A.spawn(["systemctl", "reboot"]) if c == 0 else done_cb(win, "")(c, o)))
    p.button("Réinitialiser", None, "Commencer", reset)
    p.section("Démarrage avancé")
    p.text("Problème au démarrage ? Appuyez sur Échap (ou maintenez Maj) juste après avoir allumé le PC, "
           "puis choisissez « Aion OS EDU — Restaurer le PC ».")
    p.button("Paramètres du BIOS (UEFI)", "Le PC redémarre directement dans le BIOS.", "Redémarrer maintenant",
             lambda b: A.confirm(win, "Redémarrer dans le BIOS ?", "Enregistrez votre travail avant.", "Redémarrer")
             and A.admin(["bios"], done_cb(win, "Redémarrage…")))
    return p


def page_backup(win):
    p = Page("Sauvegarde")
    p.text("Copiez le Cartable (tous les documents de classe) sur une clé USB, en un clic.", "")
    p.button("Sauvegarder le Cartable", "Branchez d'abord une clé USB.", "Sauvegarder", lambda b: A.spawn(["aion-sauvegarde"]), blue=True)
    return p


def page_security(win):
    p = Page("Sécurité")
    fw = A.run(["systemctl", "is-active", "nftables"])[1].strip() == "active"
    rows = [("Pare-feu", fw), ("Filtre parental", os.path.exists("/etc/aion/dnsfilter.enabled")),
            ("Bloqueur de publicités", os.path.exists("/etc/aion/adblock.enabled")),
            ("Mises à jour automatiques", True)]
    for name, ok in rows:
        box = Gtk.Box(spacing=10)
        box.pack_start(Gtk.Image.new_from_icon_name("emblem-ok-symbolic" if ok else "dialog-warning-symbolic", Gtk.IconSize.BUTTON), False, False, 0)
        box.pack_start(A.label(name + (" : actif" if ok else " : désactivé"), "aion-ok" if ok else "aion-error"), False, False, 0)
        p.pack_start(box, False, False, 2)
    need_admin_note(p)
    ad = os.path.exists("/etc/aion/adblock.enabled")
    p.switch("Bloqueur de publicités et de pisteurs", None, ad,
             lambda on, _s: A.admin(["adblock", "on" if on else "off"], done_cb(win, "Réglage enregistré.")))
    return p


def page_admintools(win):
    p = Page("Outils d'administration")
    p.text("Pour l'enseignant ou le parent : diagnostiquer et entretenir le PC.")
    term = lambda cmd: A.spawn(["xfce4-terminal", "--hide-menubar", "--title=Docteur", "-x"] + cmd)  # noqa: E731
    p.button("Docteur", "Bilan de santé complet : températures, disque, batterie, erreurs.", "Lancer",
             lambda b: term(["aion-doctor", "--pause"]))
    p.button("Capteurs en direct", "Températures, ventilateurs, charge.", "Ouvrir", lambda b: A.spawn(["aion-live-sensors"]))
    p.button("Test de vitesse", "Mesure la vitesse du processeur, de la mémoire et du disque.", "Ouvrir", lambda b: A.spawn(["aion-bench"]))
    p.button("Vérification du matériel", "Test rapide de la santé du PC.", "Lancer", lambda b: A.spawn(["aion-bootcheck", "--now"]))
    p.button("Gestionnaire des tâches", None, "Ouvrir", lambda b: A.spawn(["aion-taskmgr"]))
    p.button("Terminal", "Pour les commandes comme aion-mesures.", "Ouvrir", lambda b: A.spawn(["xfce4-terminal"]))
    p.section("BIOS et batterie")
    p.button("Mise à jour du BIOS et des micrologiciels", "Cherche les mises à jour officielles du fabricant (fwupd).", "Rechercher",
             lambda b: A.admin(["firmware"], lambda c, o: A.message(win, "Micrologiciels", o.strip()[-1500:] or "Rien à signaler.")))
    lim = os.path.exists("/etc/aion/charge-limit.enabled")
    p.switch("Limiter la charge à 80 %", "Les PC toujours branchés gardent une batterie en bonne santé bien plus longtemps "
             "(Dell, Lenovo, Asus et d'autres).", lim,
             lambda on, _s: A.admin(["chargelimit", "on" if on else "off"],
                                    lambda c, o: done_cb(win, "Limite de charge " + ("activée." if on else "désactivée."))(c, o) if c != 3
                                    else win.toast("Ce PC ne permet pas de limiter la charge.")))
    return p


ADULT_PIN = "/etc/aion/adulte-pin"
# Pages a pupil can open without the adult PIN
CHILD_PAGES = {"display", "sound", "a11y", "reading", "vkbd", "about"}


def ask_pin(win, title, text, twice=False):
    """Small dialog asking a 4-digit PIN. Returns the PIN or None."""
    d = Gtk.Dialog(title=title, transient_for=win, modal=True)
    d.add_buttons("Annuler", Gtk.ResponseType.CANCEL, "OK", Gtk.ResponseType.OK)
    d.set_default_response(Gtk.ResponseType.OK)
    box = d.get_content_area()
    box.set_border_width(18)
    box.set_spacing(10)
    box.pack_start(A.label(text, wrap=True), False, False, 0)
    entries = []
    for _ in range(2 if twice else 1):
        e = Gtk.Entry(visibility=False, max_length=4, input_purpose=Gtk.InputPurpose.PIN, activates_default=True)
        e.set_width_chars(8)
        box.pack_start(e, False, False, 0)
        entries.append(e)
    if twice:
        entries[1].set_placeholder_text("Encore une fois")
    d.show_all()
    r = d.run()
    vals = [e.get_text().strip() for e in entries]
    d.destroy()
    if r != Gtk.ResponseType.OK:
        return None
    if not re.fullmatch(r"\d{4}", vals[0]):
        win.toast("Le code doit contenir 4 chiffres.")
        return None
    if twice and vals[0] != vals[1]:
        win.toast("Les deux codes ne sont pas pareils.")
        return None
    return vals[0]


def new_adult_pin(win, then=None):
    pin = ask_pin(win, "Code PIN adulte", "Choisissez un code PIN adulte à 4 chiffres (différent de celui des élèves). "
                  "Le mot de passe administrateur sera demandé.", twice=True)
    if not pin:
        return
    code, out = A.run(["pkexec", "/usr/lib/aion/aion-adulte"], timeout=120, input_text=pin + "\n")
    if code == 0:
        win.toast("Code PIN adulte enregistré.")
        if then:
            then()
    elif code in (126, 127):
        win.toast("Annulé (mot de passe administrateur requis).")
    else:
        win.toast((out.strip().splitlines() or ["Échec."])[-1])


def adult_unlock(win, then):
    """Ask the adult PIN, then run then(). Administrators never need it."""
    if win.adult:
        then()
        return
    if not os.path.exists(ADULT_PIN):
        new_adult_pin(win, lambda: win.set_adult(True, then))
        return
    pin = ask_pin(win, "Mode adulte", "Cette page est réservée aux adultes. Tapez le code PIN adulte :")
    if pin is None:
        return
    code, _out = A.run(["pkexec", "/usr/lib/aion/aion-adulte-verifier"], timeout=30, input_text=pin + "\n")
    if code == 0:
        win.set_adult(True, then)
    elif code == 4:
        win.toast("Trop d'essais. Attendez 5 minutes.")
    else:
        win.toast("Code incorrect.")


PAGES = [
    ("display", "system", "Affichage", "video-display-symbolic", page_display),
    ("sound", "system", "Son", "audio-volume-high-symbolic", page_sound),
    ("notifications", "system", "Notifications", "preferences-system-notifications-symbolic", page_notifications),
    ("power", "system", "Alimentation et batterie", "battery-good-symbolic", page_power),
    ("storage", "system", "Stockage", "drive-harddisk-symbolic", page_storage),
    ("multitask", "system", "Multitâche", "preferences-system-windows-symbolic", page_multitask),
    ("about", "system", "À propos de", "help-about-symbolic", page_about),
    ("bluetooth", "devices", "Bluetooth", "bluetooth-active-symbolic", page_bluetooth),
    ("printers", "devices", "Imprimantes", "printer-symbolic", page_printers),
    ("mouse", "devices", "Souris et pavé tactile", "input-mouse-symbolic", page_mouse),
    ("keyboard", "devices", "Clavier", "input-keyboard-symbolic", page_keyboard),
    ("status", "network", "État", "network-workgroup-symbolic", page_status),
    ("wifi", "network", "Wi-Fi", "network-wireless-symbolic", page_wifi),
    ("airplane", "network", "Mode Avion", "airplane-mode-symbolic", page_airplane),
    ("filter", "network", "Filtre parental", "security-high-symbolic", page_filter),
    ("background", "personal", "Arrière-plan", "preferences-desktop-wallpaper-symbolic", page_background),
    ("effects", "personal", "Couleurs et effets", "applications-graphics-symbolic", page_effects),
    ("account", "accounts", "Vos informations", "avatar-default-symbolic", page_account),
    ("signin", "accounts", "Options de connexion", "dialog-password-symbolic", page_signin),
    ("others", "accounts", "Autres utilisateurs", "system-users-symbolic", page_others),
    ("screentime", "accounts", "Temps d'écran", "preferences-system-time-symbolic", page_screentime),
    ("datetime", "time", "Date et heure", "preferences-system-time-symbolic", page_datetime),
    ("language", "time", "Langue et clavier", "preferences-desktop-locale-symbolic", page_language),
    ("a11y", "a11y", "Affichage et texte", "preferences-desktop-font-symbolic", page_a11y),
    ("reading", "a11y", "Lecture à voix haute", "audio-speakers-symbolic", page_reading),
    ("vkbd", "a11y", "Clavier visuel et loupe", "input-keyboard-symbolic", page_vkbd),
    ("privacy", "privacy", "Micro", "audio-input-microphone-symbolic", page_privacy),
    ("update", "update", "Mises à jour", "software-update-available-symbolic", page_update),
    ("recovery", "update", "Récupération", "edit-undo-symbolic", page_recovery),
    ("backup", "update", "Sauvegarde", "drive-removable-media-symbolic", page_backup),
    ("security", "update", "Sécurité", "security-high-symbolic", page_security),
    ("admintools", "update", "Outils d'administration", "applications-system-symbolic", page_admintools),
]


class Settings(Gtk.Window):
    def __init__(self, start_page=None):
        super().__init__(title="Paramètres")
        A.fit_window(self, 980, 660)
        self.set_icon_name("aion-parametres")
        self.adult = A.is_admin()      # pupils: only CHILD_PAGES until the adult PIN is typed
        self.relock_id = 0
        A.load_css()
        self.overlay = Gtk.Overlay()
        self.add(self.overlay)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=120)
        self.overlay.add(self.stack)
        self.toast_label = Gtk.Label()
        self.toast_box = Gtk.EventBox()
        self.toast_box.add(self.toast_label)
        self.toast_box.get_style_context().add_class("aion-toast")
        self.toast_box.set_halign(Gtk.Align.CENTER)
        self.toast_box.set_valign(Gtk.Align.END)
        self.toast_box.set_margin_bottom(24)
        self.toast_box.set_no_show_all(True)
        self.overlay.add_overlay(self.toast_box)
        self.stack.add_named(self.build_home(), "home")
        self.current_page = None
        self.current_cat = None
        self.cat_view = None
        prov = Gtk.CssProvider()
        prov.load_from_data(b".aion-toast { background: #2b2b2b; color: #fff; padding: 10px 18px; }")
        Gtk.StyleContext.add_provider_for_screen(self.get_screen(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.show_all()
        if start_page:
            self.open_page(start_page)

    def allowed(self, pid):
        return self.adult or pid in CHILD_PAGES

    def set_adult(self, on, then=None):
        """Adult mode on/off: rebuilds the home page; locks again by itself after 15 minutes."""
        self.adult = on or A.is_admin()
        if self.relock_id:
            GLib.source_remove(self.relock_id)
            self.relock_id = 0
        if on and not A.is_admin():
            self.relock_id = GLib.timeout_add_seconds(900, lambda: (self.set_adult(False), False)[1])
        old = self.stack.get_child_by_name("home")
        self.stack.remove(old)
        home = self.build_home()
        self.stack.add_named(home, "home")
        home.show_all()
        if self.cat_view:
            self.stack.remove(self.cat_view)
            self.cat_view = None
        self.stack.set_visible_child_name("home")
        if then:
            then()

    def toast(self, text):
        if not text:
            return
        self.toast_label.set_text(text)
        self.toast_box.show_all()
        GLib.timeout_add_seconds(4, lambda: (self.toast_box.hide(), False)[1])

    def build_home(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_top(28)
        if not A.is_admin():
            lock = Gtk.Button(label="🔓 Mode adulte : verrouiller" if self.adult else "🔒 Mode adulte")
            lock.set_halign(Gtk.Align.END)
            lock.set_margin_end(24)
            lock.connect("clicked", lambda _b: self.set_adult(False) if self.adult else adult_unlock(self, lambda: None))
            box.pack_start(lock, False, False, 0)
        box.pack_start(A.label("Paramètres", "aion-title", xalign=0.5), False, False, 0)
        search = Gtk.SearchEntry(placeholder_text="Rechercher un paramètre")
        search.set_size_request(380, -1)
        search.set_halign(Gtk.Align.CENTER)
        box.pack_start(search, False, False, 6)
        results = Gtk.ListBox()
        results.set_halign(Gtk.Align.CENTER)
        results.set_size_request(380, -1)
        results.connect("row-activated", lambda _l, r: self.open_page(r.page_id))
        box.pack_start(results, False, False, 0)

        def on_search(e):
            for c in results.get_children():
                results.remove(c)
            q = e.get_text().strip().lower()
            if q:
                for pid, _cat, title, icon, _f in PAGES:
                    if (q in title.lower() or q in pid) and self.allowed(pid):
                        row = Gtk.ListBoxRow()
                        row.page_id = pid
                        h = Gtk.Box(spacing=10)
                        h.set_border_width(6)
                        h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.MENU), False, False, 0)
                        h.pack_start(A.label(title), False, False, 0)
                        row.add(h)
                        results.add(row)
            results.show_all()
        search.connect("search-changed", on_search)
        search.connect("activate", lambda e: results.get_row_at_index(0) and self.open_page(results.get_row_at_index(0).page_id))
        grid = Gtk.FlowBox(max_children_per_line=3, min_children_per_line=3, selection_mode=Gtk.SelectionMode.NONE,
                           column_spacing=10, row_spacing=10, homogeneous=True)
        grid.set_margin_start(40)
        grid.set_margin_end(40)
        grid.set_margin_top(16)
        grid.set_valign(Gtk.Align.START)
        for cid, title, desc, icon in CATEGORIES:
            if not any(self.allowed(p[0]) for p in PAGES if p[1] == cid):
                continue
            b = Gtk.Button()
            b.get_style_context().add_class("aion-cat")
            b.set_relief(Gtk.ReliefStyle.NONE)
            h = Gtk.Box(spacing=14)
            img = Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.DIALOG)
            img.set_pixel_size(36)
            h.pack_start(img, False, False, 0)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            v.pack_start(A.label(title), False, False, 0)
            d = A.label(desc, "aion-dim aion-small", wrap=True)
            d.set_max_width_chars(28)
            v.pack_start(d, False, False, 0)
            h.pack_start(v, True, True, 0)
            b.add(h)
            b.connect("clicked", lambda _b, c=cid: self.open_category(c))
            grid.add(b)
        sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.add(grid)
        box.pack_start(sc, True, True, 0)
        return box

    def open_category(self, cid, page_id=None):
        pages = [p for p in PAGES if p[1] == cid and self.allowed(p[0])]
        if not pages:
            return
        if not page_id:
            page_id = pages[0][0]
        if self.cat_view:
            self.stack.remove(self.cat_view)
        self.current_cat = cid
        paned = Gtk.Box()
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side.get_style_context().add_class("aion-side")
        side.set_size_request(260, -1)
        home = Gtk.Button()
        home.set_relief(Gtk.ReliefStyle.NONE)
        hb = Gtk.Box(spacing=10)
        hb.pack_start(Gtk.Image.new_from_icon_name("go-home-symbolic", Gtk.IconSize.BUTTON), False, False, 0)
        hb.pack_start(A.label("Accueil"), False, False, 0)
        home.add(hb)
        home.set_margin_top(10)
        home.connect("clicked", lambda *_: self.stack.set_visible_child_name("home"))
        side.pack_start(home, False, False, 0)
        cat_lab = A.label(next(c[1] for c in CATEGORIES if c[0] == cid), "aion-h2")
        cat_lab.set_margin_start(16)
        side.pack_start(cat_lab, False, False, 8)
        lb = Gtk.ListBox()
        lb.get_style_context().add_class("aion-side")
        for pid, _c, title, icon, _f in pages:
            row = Gtk.ListBoxRow()
            row.page_id = pid
            h = Gtk.Box(spacing=12)
            h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON), False, False, 0)
            h.pack_start(A.label(title), False, False, 0)
            row.add(h)
            lb.add(row)
            if pid == page_id:
                lb.select_row(row)
        lb.connect("row-activated", lambda _l, r: self.show_page(r.page_id))
        side.pack_start(lb, True, True, 0)
        paned.pack_start(side, False, False, 0)
        self.content = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        paned.pack_start(self.content, True, True, 0)
        self.cat_view = paned
        self.stack.add_named(paned, "cat")
        paned.show_all()
        self.stack.set_visible_child_name("cat")
        self.show_page(page_id)

    def show_page(self, pid):
        entry = next((p for p in PAGES if p[0] == pid), None)
        if not entry:
            return
        self.current_page = pid
        for c in self.content.get_children():
            self.content.remove(c)
        try:
            page = entry[4](self)
        except Exception as e:  # noqa: BLE001 — a broken page must not close the app
            page = Page(entry[2])
            page.text("Cette page n'a pas pu s'afficher : " + str(e), "aion-error")
        page.set_size_request(560, -1)
        page.set_halign(Gtk.Align.START)
        self.content.add(page)
        self.content.show_all()

    def open_page(self, pid):
        entry = next((p for p in PAGES if p[0] == pid), None)
        if entry and not self.allowed(pid):
            adult_unlock(self, lambda: self.open_category(entry[1], pid))
        elif entry:
            self.open_category(entry[1], pid)

    def reload_later(self, ms):
        GLib.timeout_add(ms, lambda: (self.current_page and self.show_page(self.current_page), False)[1])


def main():
    page = None
    if "--page" in sys.argv:
        i = sys.argv.index("--page")
        page = sys.argv[i + 1] if i + 1 < len(sys.argv) else None
    win = Settings(page)
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Aion OS EDU — Centre de notifications (Windows 10 Action Center).

A pane on the right edge: notifications on top, quick tiles (Wi-Fi,
Bluetooth, mode Avion, veilleuse, économiseur, ne pas déranger, clavier
visuel, paramètres) and brightness/volume sliders at the bottom.
Toggle: aion-centre (Windows + A or the speech-bubble icon in the taskbar).
"""
import os
import re
import sys

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

CSS = b"""
.centre { background: #1f1f1f; }
.centre, .centre label { color: #fff; }
.qtile, .qtile label, .qtile image { color: #ffffff; }
.qtile { background: #3b3b3b; border: none; border-radius: 0; padding: 8px; min-height: 58px; }
.qtile:hover { background: #4a4a4a; }
.qtile.on { background: #0078d7; }
.qtile.on:hover { background: #1a86dd; }
.ctitle { font-size: 13pt; }
.centre scale trough { background: #555; min-height: 4px; }
.centre scale highlight { background: #0078d7; }
.centre scale slider { background: #fff; min-width: 10px; min-height: 22px; border-radius: 0; }
"""


def nm_wifi_on():
    return A.run(["nmcli", "radio", "wifi"])[1].strip() == "enabled"


def bt_on():
    code, out = A.run(["bluetoothctl", "show"], timeout=3)
    return "Powered: yes" in out


def airplane_on():
    return "enabled" not in A.run(["nmcli", "radio", "all"])[1]


def dnd_on():
    return A.xfconf_get("xfce4-notifyd", "/do-not-disturb", "false") == "true"


def night_on():
    return bool((A.load_json("settings.json", {}) or {}).get("night_light"))


def saver_on():
    return os.path.exists("/run/aion/battery-saver")


def osk_on():
    return A.run(["pgrep", "-u", str(os.getuid()), "-x", "onboard"])[0] == 0


class Centre(Gtk.Window):
    def __init__(self):
        super().__init__(title="Centre de notifications")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_keep_above(True)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.get_style_context().add_class("centre")
        A.load_css(CSS)
        self.connect("key-press-event", lambda w, e: (self.destroy(), True)[1] if e.keyval == Gdk.KEY_Escape else False)
        self.connect("focus-out-event", lambda *_: (self.destroy(), False)[1])
        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        wa = mon.get_workarea()
        width = 380
        self.set_default_size(width, wa.height)
        self.move(wa.x + wa.width - width, wa.y)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_border_width(14)
        self.add(box)
        head = Gtk.Box()
        head.pack_start(A.label("Notifications", "ctitle"), True, True, 0)
        hist = Gtk.Button(label="Historique")
        hist.set_relief(Gtk.ReliefStyle.NONE)
        hist.connect("clicked", lambda *_: self.run_and_close(["xfce4-notifyd-config"]))
        head.pack_end(hist, False, False, 0)
        box.pack_start(head, False, False, 0)
        self.notes = A.label("Aucune nouvelle notification", "aion-dim", xalign=0.5)
        box.pack_start(self.notes, True, True, 0)

        grid = Gtk.Grid(column_spacing=4, row_spacing=4, column_homogeneous=True)
        tiles = [
            ("Wi-Fi", "network-wireless-symbolic", nm_wifi_on, lambda on: A.run(["nmcli", "radio", "wifi", "on" if on else "off"])),
            ("Bluetooth", "bluetooth-active-symbolic", bt_on, lambda on: A.run_async(["bluetoothctl", "power", "on" if on else "off"])),
            ("Mode Avion", "airplane-mode-symbolic", airplane_on, self.set_airplane),
            ("Veilleuse", "night-light-symbolic", night_on, self.set_night),
            ("Économiseur", "battery-good-symbolic", saver_on,
             lambda on: A.run_async(["pkexec", "/usr/lib/aion/aion-power", "on" if on else "off"])),
            ("Ne pas déranger", "notifications-disabled-symbolic", dnd_on,
             lambda on: A.xfconf_set("xfce4-notifyd", "/do-not-disturb", "true" if on else "false", "bool")),
            ("Clavier visuel", "input-keyboard-symbolic", osk_on,
             lambda on: A.spawn(["onboard"]) if on else A.run(["pkill", "-u", str(os.getuid()), "-x", "onboard"])),
            ("Paramètres", "emblem-system-symbolic", None, lambda on: self.run_and_close(["aion-parametres"])),
        ]
        for i, (name, icon, getter, setter) in enumerate(tiles):
            grid.attach(self.tile(name, icon, getter, setter), i % 4, i // 4, 1, 1)
        box.pack_end(self.sliders(), False, False, 6)
        box.pack_end(grid, False, False, 0)
        self.show_all()
        self.present()

    def tile(self, name, icon, getter, setter):
        b = Gtk.Button()
        b.get_style_context().add_class("qtile")
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        v.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        lab = A.label(name, "aion-small", xalign=0.0)
        v.pack_start(lab, False, False, 0)
        b.add(v)
        state = {"on": bool(getter()) if getter else False}
        if state["on"]:
            b.get_style_context().add_class("on")

        def clicked(_b):
            if getter is None:
                setter(True)
                return
            state["on"] = not state["on"]
            ctx = b.get_style_context()
            (ctx.add_class if state["on"] else ctx.remove_class)("on")
            setter(state["on"])
        b.connect("clicked", clicked)
        return b

    def sliders(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        code, out = A.run(["brightnessctl", "-m"])
        m = re.search(r"(\d+)%", out)
        if code == 0 and m:
            box.pack_start(self.slider("display-brightness-symbolic", int(m.group(1)),
                                       lambda v: A.run(["brightnessctl", "-q", "set", f"{max(v, 5)}%"])), False, False, 0)
        code, out = A.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"])
        m = re.search(r"([\d.]+)", out)
        vol = int(float(m.group(1)) * 100) if m else 50
        box.pack_start(self.slider("audio-volume-high-symbolic", vol,
                                   lambda v: A.run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{v / 100:.2f}"])), False, False, 0)
        return box

    def slider(self, icon, value, on_change):
        h = Gtk.Box(spacing=10)
        h.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        sc = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=Gtk.Adjustment(value=value, lower=0, upper=100,
                                                                                          step_increment=5, page_increment=10), digits=0)
        sc.set_draw_value(False)
        sc.connect("value-changed", lambda s: on_change(int(s.get_value())))
        h.pack_start(sc, True, True, 0)
        return h

    def set_airplane(self, on):
        if on:
            A.run(["nmcli", "radio", "all", "off"])
            A.run_async(["bluetoothctl", "power", "off"])
        else:
            A.run(["nmcli", "radio", "all", "on"])

    def set_night(self, on):
        s = A.load_json("settings.json", {}) or {}
        s["night_light"] = on
        A.save_json("settings.json", s)
        A.spawn(["/usr/lib/aion/aion-nightlight", "on" if on else "off"])

    def run_and_close(self, cmd):
        A.spawn(cmd)
        self.destroy()


def main():
    # second press closes the pane (like Windows)
    me = os.getpid()
    code, out = A.run(["pgrep", "-u", str(os.getuid()), "-f", r"^python3 /usr/lib/aion/centre\.py"])
    others = [int(p) for p in out.split() if p.isdigit() and int(p) != me]
    if others:
        for pid in others:
            try:
                os.kill(pid, 15)
            except OSError:
                pass
        return
    win = Centre()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

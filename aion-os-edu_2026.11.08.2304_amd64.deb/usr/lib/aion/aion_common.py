"""Aion OS EDU — shared helpers for Aion's own apps (GTK 3, French UI).

Every Aion app imports this: Windows 10 style CSS, running commands without
freezing the window, asking for the administrator password (pkexec), and
small settings files in ~/.config/aion.
"""
import grp
import json
import os
import pwd
import shutil
import subprocess
import threading

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

ACCENT = "#0078d7"
ADMIN_HELPER = "/usr/lib/aion/aion-admin"
CONFIG_DIR = os.path.join(GLib.get_user_config_dir(), "aion")

# Windows 10 look for Aion's own windows (on top of the Aion10 GTK theme).
APP_CSS = b"""
.aion-title { font-size: 22pt; font-weight: 300; }
.aion-h2 { font-size: 15pt; font-weight: 400; margin-top: 12px; }
.aion-dim { color: alpha(currentColor, 0.62); }
.aion-small { font-size: 9pt; }
.aion-card { background: #f2f2f2; padding: 14px; }
.aion-cat { background: transparent; border: 1px solid transparent; padding: 12px; }
.aion-cat:hover { border-color: #c8c8c8; background: #f7f7f7; }
.aion-side { background: #f2f2f2; }
.aion-side row { padding: 10px 16px; }
.aion-side row:selected { background: #dcdcdc; color: #000; box-shadow: inset 4px 0 0 #0078d7; }
.aion-blue { background: #0078d7; color: #fff; border: none; padding: 8px 20px; }
.aion-blue:hover { background: #1a86dd; }
.aion-blue:disabled { background: #cccccc; color: #888; }
.aion-tile { color: #fff; border: 2px solid transparent; padding: 6px; }
.aion-tile:hover { border-color: rgba(255,255,255,0.55); }
.aion-tile-label { font-size: 9pt; color: #fff; }
.aion-error { color: #c42b1c; }
.aion-ok { color: #107c10; }
"""


def fit_window(win, w, h):
    """Default size w x h, or maximized when the screen is smaller than that
    (1024x600 netbooks, 4:3 and 5:4 screens…)."""
    try:
        disp = Gdk.Display.get_default()
        wa = (disp.get_primary_monitor() or disp.get_monitor(0)).get_workarea()
    except Exception:
        win.set_default_size(w, h)
        return
    if w > wa.width - 40 or h > wa.height - 40:
        win.set_default_size(min(w, wa.width), min(h, wa.height))
        win.maximize()
    else:
        win.set_default_size(w, h)


def load_css(extra=b""):
    prov = Gtk.CssProvider()
    prov.load_from_data(APP_CSS + extra)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


def have(cmd):
    return shutil.which(cmd) is not None


def run(cmd, timeout=15, input_text=None):
    """Run a command and return (exit code, output). Never raises."""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input_text)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.SubprocessError) as e:
        return 127, str(e)


def spawn(cmd):
    """Start a program and forget about it (it keeps running if we close)."""
    try:
        subprocess.Popen(cmd, start_new_session=True, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        return True
    except OSError:
        return False


def run_async(cmd, callback=None, timeout=600, input_text=None):
    """Run in a thread; callback(code, output) is called back in the GTK main loop."""
    def work():
        code, out = run(cmd, timeout=timeout, input_text=input_text)
        if callback:
            GLib.idle_add(lambda: (callback(code, out), False)[1])
    threading.Thread(target=work, daemon=True).start()


def admin(args, callback=None, input_text=None):
    """Run the Aion admin helper as root. Shows the administrator password box."""
    run_async(["pkexec", ADMIN_HELPER] + list(args), callback, input_text=input_text)


def user_name():
    return pwd.getpwuid(os.getuid()).pw_name


def full_name(user=None):
    try:
        pw = pwd.getpwnam(user or user_name())
        return (pw.pw_gecos.split(",")[0] or pw.pw_name).strip()
    except KeyError:
        return user or ""


def is_admin(user=None):
    user = user or user_name()
    try:
        return user in grp.getgrnam("sudo").gr_mem
    except KeyError:
        return False


def students():
    """Normal accounts (UID 1000+) that are not administrators."""
    out = []
    for pw in pwd.getpwall():
        if 1000 <= pw.pw_uid < 60000 and pw.pw_shell not in ("/usr/sbin/nologin", "/bin/false"):
            if not is_admin(pw.pw_name):
                out.append(pw.pw_name)
    return sorted(out)


def load_json(name, default=None):
    for path in (os.path.join(CONFIG_DIR, name), os.path.join("/etc/aion", name)):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            continue
    return default


def save_json(name, data):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    path = os.path.join(CONFIG_DIR, name)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def xfconf_get(channel, prop, default=None):
    code, out = run(["xfconf-query", "-c", channel, "-p", prop], timeout=5)
    return out.strip() if code == 0 else default


def xfconf_set(channel, prop, value, kind="string"):
    return run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", kind, "-s", str(value)], timeout=5)[0] == 0


def message(parent, title, text, kind=Gtk.MessageType.INFO):
    d = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=kind,
                          buttons=Gtk.ButtonsType.OK, text=title)
    if text:
        d.format_secondary_text(text)
    d.run()
    d.destroy()


def confirm(parent, title, text, ok_label="Continuer"):
    d = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.QUESTION,
                          buttons=Gtk.ButtonsType.NONE, text=title)
    if text:
        d.format_secondary_text(text)
    d.add_button("Annuler", Gtk.ResponseType.CANCEL)
    d.add_button(ok_label, Gtk.ResponseType.OK)
    d.set_default_response(Gtk.ResponseType.CANCEL)
    r = d.run()
    d.destroy()
    return r == Gtk.ResponseType.OK


def label(text, css=None, wrap=False, xalign=0.0, selectable=False):
    lab = Gtk.Label(label=text, xalign=xalign)
    lab.set_line_wrap(wrap)
    if wrap:
        lab.set_max_width_chars(70)
    lab.set_selectable(selectable)
    for c in (css or "").split():
        lab.get_style_context().add_class(c)
    return lab


def human_bytes(n):
    n = float(n)
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if n < 1024 or unit == "To":
            return (f"{n:.0f} {unit}" if unit in ("o", "Ko") else f"{n:.1f} {unit}").replace(".", ",")
        n /= 1024
    return str(n)

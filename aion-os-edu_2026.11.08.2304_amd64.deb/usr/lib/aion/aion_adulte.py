"""Aion OS EDU — the adult PIN (4 digits) that unlocks every page of Paramètres.

Stored hashed in /etc/aion/adulte-pin (root only). Checked by aion-adulte-verifier
(no password asked, but 5 wrong codes = 5 minutes of waiting); changed by
aion-adulte (administrator password asked by pkexec).
"""
import hashlib
import json
import os
import re
import time

PIN_FILE = "/etc/aion/adulte-pin"
TRIES = "/var/lib/aion/adulte-essais.json"
MAX_TRIES, WAIT = 5, 300


def _hash(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), salt, 120000).hex()


def set_pin(pin):
    if not re.fullmatch(r"\d{4}", pin):
        raise ValueError("Le code PIN adulte doit contenir 4 chiffres.")
    salt = os.urandom(16)
    os.makedirs(os.path.dirname(PIN_FILE), exist_ok=True)
    fd = os.open(PIN_FILE + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(salt.hex() + ":" + _hash(pin, salt) + "\n")
    os.replace(PIN_FILE + ".tmp", PIN_FILE)


def check_pin(pin):
    """0 = right, 1 = wrong, 3 = no adult PIN yet, 4 = too many tries (wait)."""
    try:
        salt_hex, good = open(PIN_FILE).read().strip().split(":")
    except (OSError, ValueError):
        return 3
    try:
        st = json.load(open(TRIES))
    except (OSError, ValueError):
        st = {"n": 0, "until": 0}
    if time.time() < st.get("until", 0):
        return 4
    if re.fullmatch(r"\d{4}", pin) and _hash(pin, bytes.fromhex(salt_hex)) == good:
        st = {"n": 0, "until": 0}
        code = 0
    else:
        st["n"] = st.get("n", 0) + 1
        if st["n"] >= MAX_TRIES:
            st = {"n": 0, "until": time.time() + WAIT}
        code = 1
    os.makedirs(os.path.dirname(TRIES), exist_ok=True)
    with open(TRIES, "w") as f:
        json.dump(st, f)
    return code

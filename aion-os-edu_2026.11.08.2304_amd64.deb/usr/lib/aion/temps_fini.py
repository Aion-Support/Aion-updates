#!/usr/bin/env python3
"""Aion OS EDU — « Le temps est fini » : shown to the pupil by the screen-time service
before the session locks. Button « Demander plus de temps » : an adult types the
adult PIN and gives 15, 30 or 60 more minutes. Without it, the session locks
after 2 minutes."""
import sys

sys.path.insert(0, "/usr/lib/aion")
import aion_common as A  # noqa: E402
from gi.repository import Gtk  # noqa: E402

CSS = b"""
.tf { background: #1f3b5c; }
.tf label { color: #fff; }
.tf-big { font-size: 30pt; font-weight: 700; }
.tf-mid { font-size: 16pt; }
.tf button { font-size: 15pt; padding: 12px 24px; }
"""


def main():
    msg = sys.argv[1] if len(sys.argv) > 1 else "Le temps d'ordinateur est fini pour aujourd'hui."
    A.load_css(CSS)
    win = Gtk.Window(title="Temps d'ordinateur")
    win.get_style_context().add_class("tf")
    win.set_keep_above(True)
    win.fullscreen()
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24, valign=Gtk.Align.CENTER, halign=Gtk.Align.CENTER)
    win.add(box)
    box.pack_start(A.label("⏰  C'est fini !", "tf-big", xalign=0.5), False, False, 0)
    box.pack_start(A.label(msg + "\nEnregistre ton travail. L'ordinateur va se verrouiller dans 2 minutes.",
                           "tf-mid", wrap=True, xalign=0.5), False, False, 0)
    status = A.label("", "tf-mid", xalign=0.5)
    ask = Gtk.Button(label="🙋  Demander plus de temps à un adulte")
    ask.get_style_context().add_class("aion-blue")
    box.pack_start(ask, False, False, 0)
    box.pack_start(status, False, False, 0)

    def on_ask(_b):
        d = Gtk.Dialog(title="Plus de temps", transient_for=win, modal=True)
        d.add_buttons("Annuler", Gtk.ResponseType.CANCEL, "Donner", Gtk.ResponseType.OK)
        c = d.get_content_area()
        c.set_border_width(18)
        c.set_spacing(10)
        c.pack_start(A.label("Pour l'adulte : combien de temps en plus ?"), False, False, 0)
        combo = Gtk.ComboBoxText()
        for m in ("15", "30", "60"):
            combo.append(m, m + " minutes")
        combo.set_active_id("15")
        c.pack_start(combo, False, False, 0)
        c.pack_start(A.label("Code PIN adulte :"), False, False, 0)
        e = Gtk.Entry(visibility=False, max_length=4, input_purpose=Gtk.InputPurpose.PIN, activates_default=True)
        c.pack_start(e, False, False, 0)
        d.set_default_response(Gtk.ResponseType.OK)
        d.show_all()
        r = d.run()
        pin, minutes = e.get_text().strip(), combo.get_active_id()
        d.destroy()
        if r != Gtk.ResponseType.OK:
            return
        code, _ = A.run(["pkexec", "/usr/lib/aion/aion-temps-plus"], timeout=30, input_text=f"{pin} {minutes}\n")
        if code == 0:
            Gtk.main_quit()
        elif code == 4:
            status.set_text("Trop d'essais : attends 5 minutes.")
        elif code == 3:
            status.set_text("Aucun code PIN adulte n'est encore choisi (Paramètres → Temps d'écran).")
        else:
            status.set_text("Code incorrect.")

    ask.connect("clicked", on_ask)
    win.connect("delete-event", lambda *a: True)   # stays until the time is given or the PC locks
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
